
# Résumé des interactions avec la base de données lors de la suppression d'un rôle utilisateur

Lorsque vous supprimez un rôle d'un utilisateur et que vous cliquez sur "Valider", voici les interactions qui se produisent avec la base de données :

1. **Récupération des rôles globaux existants** :
   - L'application appelle `UtilisateurApi.getUserGlobalRoles(userId)` pour obtenir la liste actuelle des rôles globaux de l'utilisateur depuis la base de données.
   - Cette requête utilise l'endpoint `GET /user_site_role/user-role/{user_id}`.

2. **Création d'un ensemble des nouveaux rôles** :
   - L'application crée un ensemble (`newGlobalRoles`) contenant uniquement les rôles que vous avez conservés dans l'interface.
   - Chaque rôle est identifié par une clé unique au format `{userId}-{roleId}`.

3. **Comparaison et suppression des rôles** :
   - Pour chaque rôle global existant dans la base de données :
     - L'application vérifie si ce rôle existe dans l'ensemble des nouveaux rôles.
     - Si le rôle n'est plus présent (vous l'avez supprimé), l'application appelle `UtilisateurApi.deleteUserGlobalRole(userId, roleId)`.
     - Cette requête utilise l'endpoint `DELETE /user_site_role/user-role/{user_id}/{role_id}` pour supprimer définitivement l'association entre l'utilisateur et ce rôle dans la base de données.

4. **Journalisation des actions** :
   - L'application enregistre des messages de débogage pour suivre le processus :
     - "Deleting global role {roleName} (ID: {roleId}) from user {userId}"
     - "Successfully deleted global role {roleName} from user {userId}"

5. **Rafraîchissement des données utilisateur** :
   - Après toutes les modifications, l'application appelle `UtilisateurApi.getUserById(userId)` pour récupérer les données mises à jour de l'utilisateur depuis la base de données.
   - L'interface utilisateur est ensuite mise à jour pour refléter ces changements.

En résumé, lorsque vous supprimez un rôle et validez, l'application identifie précisément quels rôles ont été supprimés et envoie des requêtes DELETE spécifiques à la base de données pour supprimer uniquement ces associations, tout en préservant les autres rôles de l'utilisateur.
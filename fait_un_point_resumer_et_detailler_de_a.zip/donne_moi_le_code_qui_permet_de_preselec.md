```markdown
# Code pour la présélection des rôles et sites utilisateur

## 1. Présélection des rôles dans le dialogue utilisateur

Voici le code qui permet de présélectionner les rôles d'un utilisateur lors de la modification :

```dart
// Dans la classe _UtilisateurDialogState (utilisateur_dialog.dart)
@override
void initState() {
  super.initState();

  // Si on modifie un utilisateur existant, on pré-remplit les champs
  if (widget.initialUser != null) {
    _usernameController.text = widget.initialUser!.login;

    // Debug: Print detailed information about the user
    print("Initial user: ${widget.initialUser!.login} (ID: ${widget.initialUser!.id})");
    print("User sites: ${widget.initialUser!.sites.map((s) => s.name).toList()}");
    print("User globalRolesList: ${widget.initialUser!.globalRolesList.map((r) => r.name).toList()}");

    // For each site, print its roles
    for (var site in widget.initialUser!.sites) {
      print("Site ${site.name} roles: ${site.roles.map((r) => r.name).toList()}");
    }

    // Préselectionner les rôles de l'utilisateur
    final userRoles = widget.initialUser!.globalRoles;

    // Afficher les rôles pour le débogage
    print("User roles (from getter): $userRoles");

    // Préselectionner les rôles disponibles qui correspondent aux rôles de l'utilisateur
    _selectedRoles = _availableRoles
        .where((role) => userRoles.contains(role.toLowerCase()))
        .toList();

    // Afficher les rôles sélectionnés pour le débogage
    print("Selected roles: $_selectedRoles");

    // Préselectionner les sites de l'utilisateur
    _selectedSites =
        widget.initialUser!.sites.map((site) => site.name).toList();
  }
}
```

## 2. Affichage et sélection des rôles dans l'interface

```dart
// Dans la méthode build de _UtilisateurDialogState (utilisateur_dialog.dart)
// Sélection des rôles
const Text('Rôles:',
    style: TextStyle(fontWeight: FontWeight.bold)),
Wrap(
  spacing: 8.0,
  children: _availableRoles.map((role) {
    return FilterChip(
      label: Text(role),
      selected: _selectedRoles.contains(role),
      onSelected: (selected) {
        setState(() {
          if (selected) {
            _selectedRoles.add(role);
          } else {
            _selectedRoles.remove(role);
          }
        });
      },
    );
  }).toList(),
),
```

## 3. Présélection des sites dans le dialogue utilisateur

```dart
// Dans la classe _UtilisateurDialogState (utilisateur_dialog.dart)
@override
void initState() {
  super.initState();

  // Si on modifie un utilisateur existant, on pré-remplit les champs
  if (widget.initialUser != null) {
    // ... (code pour les rôles)

    // Préselectionner les sites de l'utilisateur
    _selectedSites =
        widget.initialUser!.sites.map((site) => site.name).toList();
  }
}
```

## 4. Affichage et sélection des sites dans l'interface

```dart
// Dans la méthode build de _UtilisateurDialogState (utilisateur_dialog.dart)
// Sélection des sites
const Text('Sites:',
    style: TextStyle(fontWeight: FontWeight.bold)),
if (availableSites.isEmpty)
  const Text('Aucun site disponible')
else
  Wrap(
    spacing: 8.0,
    children: availableSites.map((site) {
      return FilterChip(
        label: Text(site),
        selected: _selectedSites.contains(site),
        onSelected: (selected) {
          setState(() {
            if (selected) {
              _selectedSites.add(site);
            } else {
              _selectedSites.remove(site);
            }
          });
        },
      );
    }).toList(),
  ),
```

## 5. Affichage des sites attribués à un utilisateur dans la liste des utilisateurs

```dart
// Dans la classe _GestionUtilisateursPageState (gestion_utilisateurs.dart)
// Dans la méthode build, à l'intérieur du DataTable
DataTable(
  columns: const [
    DataColumn(label: Text('Nom d\'utilisateur')),
    DataColumn(label: Text('Rôles')),
    DataColumn(label: Text('Sites')),
    DataColumn(label: Text('Actions')),
  ],
  rows: _filteredUsers.map((user) {
    return DataRow(
      cells: [
        DataCell(Text(user.login)),
        DataCell(Text(user.globalRoles.join(', '))),
        DataCell(Text(
            user.sites.map((site) => site.name).join(', '))),
        DataCell(
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () => _createOrEditUtilisateur(
                    utilisateur: user),
                tooltip: 'Modifier',
              ),
              IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () => _deleteUtilisateur(user),
                tooltip: 'Supprimer',
              ),
            ],
          ),
        ),
      ],
    );
  }).toList(),
),
```

## 6. Modèle Utilisateur avec les propriétés pour les rôles et sites

```dart
// Dans la classe Utilisateur (utilisateur.dart)
class Utilisateur {
  final int id;
  final String login;
  final List<SiteAssociation> sites;
  final List<Role> globalRolesList;

  Utilisateur({
    required this.id,
    required this.login,
    required this.sites,
    this.globalRolesList = const [],
  });

  factory Utilisateur.fromJson(Map<String, dynamic> json) {
    var sitesList = <SiteAssociation>[];
    if (json['sites'] != null) {
      sitesList = (json['sites'] as List)
          .map((siteJson) => SiteAssociation.fromJson(siteJson))
          .toList();
    }

    var globalRolesList = <Role>[];
    // Check for global_roles field first (API documentation format)
    if (json['global_roles'] != null) {
      globalRolesList = (json['global_roles'] as List)
          .map((roleJson) => Role.fromJson(roleJson))
          .toList();
    } 
    // If global_roles is not present, check for roles field (actual API response format)
    else if (json['roles'] != null) {
      // If roles is a list of strings, convert each to a Role object
      if (json['roles'] is List && json['roles'].isNotEmpty && json['roles'][0] is String) {
        globalRolesList = (json['roles'] as List<dynamic>)
            .map((roleName) => Role(id: 0, name: roleName as String))
            .toList();
      } 
      // If roles is a list of objects, use Role.fromJson
      else if (json['roles'] is List) {
        globalRolesList = (json['roles'] as List)
            .map((roleJson) => Role.fromJson(roleJson))
            .toList();
      }
    }

    return Utilisateur(
      id: json['id'],
      login: json['login'],
      sites: sitesList,
      globalRolesList: globalRolesList,
    );
  }

  /// Agrège tous les rôles issus de chaque association de site et les rôles globaux.
  Set<String> get globalRoles {
    final rolesSet = <String>{};
    // Add site-specific roles
    for (final site in sites) {
      for (final role in site.roles) {
        rolesSet.add(role.name.toLowerCase());
      }
    }
    // Add global roles
    for (final role in globalRolesList) {
      rolesSet.add(role.name.toLowerCase());
    }
    return rolesSet;
  }
}
```

Ce code montre comment les rôles et sites sont présélectionnés dans le dialogue de modification d'utilisateur, et comment les sites attribués à un utilisateur sont affichés dans l'interface.
```

# Différence dans les données avant et après la création d'un bloc BAES

En comparant les données avant et après la création d'un bloc BAES (Bloc Autonome d'Éclairage de Sécurité), on peut identifier la différence principale suivante :

## Avant la création du bloc BAES

Dans l'étage (ID: 13, nom: "test"), le tableau `baes` était vide :

```json
"etages":[{
  "baes":[],
  "carte":{
    "center_lat":41.94657808710301,
    "center_lng":88.49712407163912,
    "chemin":"http://localhost:5000/cartes/uploads/2c1d7c43-b970-4640-a9fa-693e56442712.jpg",
    "etage_id":13,
    "id":1020,
    "site_id":null,
    "zoom":-5.0
  },
  "id":13,
  "name":"test"
}]
```

Ceci est confirmé par la réponse API à la fin des logs avant création :
```
API CALL: GET http://localhost:5000/etages/13/baes
API RESPONSE (200): []
```

## Après la création du bloc BAES

Dans le même étage (ID: 13, nom: "test"), le tableau `baes` contient maintenant un élément avec les informations du nouveau bloc BAES créé :

```json
"etages":[{
  "baes":[{
    "erreurs":[],
    "id":3010,
    "name":"testbaes",
    "position":{
      "lat":51.75907808710301,
      "lng":117.37212407163912
    }
  }],
  "carte":{
    "center_lat":41.94657808710301,
    "center_lng":88.49712407163912,
    "chemin":"http://localhost:5000/cartes/uploads/2c1d7c43-b970-4640-a9fa-693e56442712.jpg",
    "etage_id":13,
    "id":1020,
    "site_id":null,
    "zoom":-5.0
  },
  "id":13,
  "name":"test"
}]
```

## Détails du nouveau bloc BAES

Le bloc BAES ajouté a les caractéristiques suivantes :
- **ID** : 3010
- **Nom** : "testbaes"
- **Position** : 
  - Latitude : 51.75907808710301
  - Longitude : 117.37212407163912
- **Liste d'erreurs** : vide (aucune erreur pour le moment)

Cette modification est la seule différence significative entre les deux jeux de données. Toutes les autres structures (sites, bâtiments, cartes, etc.) sont restées identiques.
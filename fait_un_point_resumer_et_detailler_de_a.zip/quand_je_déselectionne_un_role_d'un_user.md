```markdown
# Implémentation de la suppression de rôles pour les utilisateurs

Pour résoudre le problème de suppression des rôles lorsqu'ils sont désélectionnés dans l'interface utilisateur, j'ai identifié qu'il manque une fonctionnalité essentielle : la suppression des rôles globaux (non liés à un site spécifique).

## Modifications nécessaires

### 1. Ajout d'une méthode `deleteUserGlobalRole` dans la classe `UtilisateurApi`

Il faut ajouter cette méthode après la méthode `deleteUserSiteRole` existante (vers la ligne 275) :

```dart
/// Supprime un rôle global d'un utilisateur (sans site spécifique).
/// Utilise l'endpoint DELETE /user_site_role/user-role/{user_id}/{role_id}
static Future<void> deleteUserGlobalRole({
  required int userId,
  required int roleId,
}) async {
  final url = Uri.parse('$baseUrl/user_site_role/user-role/$userId/$roleId');
  
  print('Envoi de la requête DELETE à $url');
  
  try {
    final response = await http.delete(url);
    
    print('Réponse reçue: Status ${response.statusCode}');
    
    if (response.statusCode != 200) {
      throw Exception(
          'Erreur lors de la suppression du rôle global de l\'utilisateur. Code HTTP: ${response.statusCode}');
    }
  } catch (e) {
    print('Exception lors de l\'envoi de la requête: $e');
    rethrow;
  }
}
```

### 2. Modification de la méthode `_createOrEditUtilisateur` dans la classe `_GestionUtilisateursPageState`

Après la section qui supprime les associations site-rôle (vers la ligne 354), il faut ajouter un bloc de code pour supprimer les rôles globaux qui ne sont plus nécessaires :

```dart
// Étape 5b: Supprimer les rôles globaux qui ne sont plus nécessaires
for (final association in existingAssociations) {
  // Les rôles globaux ont site_id à null
  if (association['site_id'] == null && association['role_id'] != null) {
    final userId = association['user_id'] as int;
    final roleId = association['role_id'] as int;
    
    // Récupérer le nom du rôle à partir de son ID
    String? roleName;
    for (final entry in roleNameToId.entries) {
      if (entry.value == roleId) {
        roleName = entry.key;
        break;
      }
    }
    
    // Vérifier si ce rôle global est toujours sélectionné
    if (roleName != null && !roles.contains(roleName)) {
      try {
        // Supprimer le rôle global car il n'est plus sélectionné
        print('Suppression du rôle global: $roleName (ID: $roleId)');
        await UtilisateurApi.deleteUserGlobalRole(
          userId: userId,
          roleId: roleId,
        );
        print('Rôle global $roleName (ID: $roleId) supprimé avec succès');
      } catch (e) {
        // Enregistrer l'erreur mais continuer
        failedOperations.add('Suppression rôle global: $roleName');
        print('Erreur lors de la suppression du rôle global $roleName (ID: $roleId): $e');
      }
    }
  }
}
```

## Explication du fonctionnement

1. Lorsqu'un utilisateur désélectionne un rôle dans l'interface, ce rôle est retiré de la liste `_selectedRoles` dans le dialogue.
2. Quand l'utilisateur valide le dialogue, la liste mise à jour des rôles est transmise à la méthode `_createOrEditUtilisateur`.
3. Cette méthode récupère d'abord les associations existantes de l'utilisateur via `getUserSiteRoles`.
4. Elle compare ensuite les rôles existants avec les rôles sélectionnés :
   - Pour les rôles spécifiques à un site, elle utilise `deleteUserSiteRole` si nécessaire.
   - Pour les rôles globaux, elle utilisera maintenant `deleteUserGlobalRole` si un rôle n'est plus sélectionné.

Ces modifications permettront de supprimer correctement les rôles d'un utilisateur lorsqu'ils sont désélectionnés dans l'interface, conformément à la procédure API décrite dans l'énoncé.
```
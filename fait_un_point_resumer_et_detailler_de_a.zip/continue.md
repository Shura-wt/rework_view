
# Solutions pour les problèmes de l'application BAES

Voici les solutions proposées pour résoudre les problèmes identifiés dans l'application BAES :

## 1. Problème : La page vue carte ne se recharge pas lors du changement de site via le drawer

**Analyse :** 
- Le changement de site est correctement géré dans le drawer (`drawer.dart` ligne 153) en appelant `siteProvider.setSelectedSite(selected)`.
- Le `SiteProvider` notifie bien ses écouteurs lors du changement de site (ligne 79).
- La page `GestionCartePage` s'abonne aux changements via `_siteProvider.addListener(_onSiteSelectionChanged)` (ligne 140).
- La méthode `_onSiteSelectionChanged()` réinitialise les données de la carte et appelle `_loadSiteMapData()`.

**Problème identifié :** 
- Bien que le code semble correct, il est possible que la page ne soit pas correctement mise à jour visuellement.

**Solution :**
1. Assurez-vous que la méthode `_loadSiteMapData()` est bien appelée après un changement de site.
2. Ajoutez un `setState(() {})` explicite après le chargement des données pour forcer le rafraîchissement de l'interface.
3. Modifiez la méthode `_onSiteSelectionChanged()` pour réinitialiser également les données d'étage :

```dart
void _onSiteSelectionChanged() {
  if (!mounted) return;

  // Reset site map data to ensure no data persistence
  setState(() {
    _siteEffectiveWidth = null;
    _siteEffectiveHeight = null;
    _currentSiteCarte = null;
    
    // Réinitialiser également les données d'étage
    _isFloorMode = false;
    _selectedBatiment = null;
    _selectedFloorId = null;
    _batimentEtages = [];
    _floorEffectiveWidth = null;
    _floorEffectiveHeight = null;
  });

  // Reload site map data for the newly selected site
  if (mounted) {
    _loadSiteMapData();
  }
}
```

## 2. Problème : Les dimensions de la carte ne sont pas changées entre les étages

**Analyse :**
- Les dimensions de la carte sont stockées dans `_floorEffectiveWidth` et `_floorEffectiveHeight`.
- Ces valeurs sont définies dans `_getFloorImageDimensions()` (lignes 2201-2202).
- Lors du changement d'étage, ces valeurs ne sont pas réinitialisées.

**Solution :**
1. Réinitialisez les dimensions de la carte lors du changement d'étage dans la méthode `_loadFloorMapData()` :

```dart
Future<void> _loadFloorMapData(int floorId) async {
  if (!mounted) {
    return;
  }

  _selectedFloorId = floorId;
  
  // Réinitialiser les dimensions de la carte
  setState(() {
    _floorEffectiveWidth = null;
    _floorEffectiveHeight = null;
  });

  // Reste du code...
}
```

2. Assurez-vous que `_getFloorImageDimensions()` est appelé pour chaque nouvelle carte d'étage.

## 3. Problème : L'icône des erreurs BAES est rouge quand il n'y a pas d'erreur

**Analyse :**
- Dans le code du drawer, les icônes de connexion et de batterie sont affichées en rouge ou vert selon la présence d'erreurs.
- Le problème pourrait être dans la logique de détection des erreurs.

**Solution :**
Vérifiez et corrigez la logique dans les classes `BAESTile` et `ErrorBAESTile` :

```dart
// Dans BAESTile et ErrorBAESTile
Icon(
  Icons.wifi,
  color: hasConnectionError ? Colors.red : Colors.green,
  size: 20,
),
```

Si l'icône est toujours rouge même sans erreur, vérifiez comment `hasConnectionError` est calculé :

```dart
bool hasConnectionError = baes.erreurs.any((e) => e.typeErreur == 'connection');
```

Assurez-vous que `baes.erreurs` est correctement initialisé et mis à jour.

## 4. Problème : Obligation de sauvegarder manuellement la carte d'un étage pour poser un BAES

**Analyse :**
- L'ajout d'un BAES nécessite que la carte de l'étage soit déjà sauvegardée.

**Solution :**
Modifiez la méthode `_addBaesMarker()` pour sauvegarder automatiquement la carte si nécessaire :

```dart
Future<void> _addBaesMarker(LatLng point, String name) async {
  if (_selectedFloorId == null) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Aucun étage sélectionné pour ajouter un BAES")),
    );
    return;
  }

  // Vérifier si la carte de l'étage est sauvegardée
  bool carteExiste = false;
  for (var carte in Carte.allCartes) {
    if (carte.etageId == _selectedFloorId) {
      carteExiste = true;
      break;
    }
  }

  // Si la carte n'existe pas, la sauvegarder automatiquement
  if (!carteExiste && _uploadedFloorImage != null) {
    // Code pour sauvegarder la carte automatiquement
    await _saveFloorMap();
  }

  // Reste du code pour ajouter le BAES...
}
```

## 5. Problème : Nécessité de changer de page manuellement pour qu'un nouveau BAES apparaisse dans le drawer

**Analyse :**
- Après l'ajout d'un BAES, le drawer n'est pas mis à jour automatiquement.

**Solution :**
1. Après l'ajout d'un BAES, notifiez les écouteurs pour mettre à jour le drawer :

```dart
Future<void> _addBaesMarker(LatLng point, String name) async {
  // Code existant...
  
  if (baes != null) {
    setState(() {
      // Réinitialiser la sélection
      _selectedBaes = null;
      _selectedBaesIndex = null;

      // Mettre à jour tous les marqueurs (y compris le nouveau)
      _updateBaesMarkers();
    });

    // Recharger uniquement les BAES pour l'étage actuel
    _loadBaesForFloor(_selectedFloorId!);
    
    // Notifier les écouteurs pour mettre à jour le drawer
    Provider.of<SiteProvider>(context, listen: false).notifyListeners();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("BAES '$name' ajouté à la carte et enregistré")),
    );
  }
}
```

## 6. Problème : La popup de chargement de carte reste à l'infini

**Analyse :**
- La popup de chargement n'est pas fermée correctement lorsque la carte est chargée.

**Solution :**
1. Assurez-vous que la popup est fermée une fois la carte chargée :

```dart
// Dans la méthode qui charge la carte
showDialog(
  context: context,
  barrierDismissible: false,
  builder: (BuildContext context) {
    return AlertDialog(
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircularProgressIndicator(),
          SizedBox(height: 16),
          Text("Téléchargement de l'image en cours..."),
        ],
      ),
    );
  },
);

// Charger la carte...

// Une fois la carte chargée, fermer la popup
if (mounted && Navigator.of(context).canPop()) {
  Navigator.of(context).pop();
}
```

2. Ajoutez un timeout pour fermer automatiquement la popup après un certain temps :

```dart
// Définir un timeout pour fermer la popup
Future.delayed(const Duration(seconds: 30), () {
  if (mounted && Navigator.of(context).canPop()) {
    Navigator.of(context).pop();
  }
});
```

Ces solutions devraient résoudre les problèmes identifiés dans l'application BAES. Certaines modifications peuvent nécessiter des ajustements en fonction de la structure exacte de votre code.
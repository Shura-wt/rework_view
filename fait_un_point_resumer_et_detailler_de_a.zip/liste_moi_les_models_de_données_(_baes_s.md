
# Modèles de données dans le projet BAES Front

Voici la liste des modèles de données présents dans le projet, organisés par leur hiérarchie et relations :

## Modèles principaux

### 1. Site
Représente un site ou un campus contenant plusieurs bâtiments.
- **Propriétés** : id, name, batiments (liste de Batiment), carte (optionnel)
- **Relations** : Contient des Batiments, peut avoir une Carte

### 2. Batiment
Représente un bâtiment au sein d'un site.
- **Propriétés** : id, name, polygonPoints (points définissant le contour du bâtiment), siteId, etages (liste d'Etage)
- **Relations** : Appartient à un Site, contient des Etages

### 3. Etage
Représente un étage dans un bâtiment.
- **Propriétés** : id, name, batimentId, carte (optionnel), baes (liste de Baes)
- **Relations** : Appartient à un Batiment, contient des Baes, peut avoir une Carte

### 4. Baes
Représente un bloc autonome d'éclairage de sécurité (BAES).
- **Propriétés** : id, name, position, etageId, erreurs (liste d'HistoriqueErreur)
- **Relations** : Appartient à un Etage, peut avoir des HistoriqueErreur

## Modèles secondaires

### 5. Carte
Représente une carte ou un plan d'étage/site.
- **Propriétés** : id, chemin, etageId (optionnel), siteId (optionnel), centerLat, centerLng, zoom
- **Relations** : Peut être associée à un Etage ou un Site

### 6. HistoriqueErreur
Représente l'historique des erreurs pour un BAES.
- **Propriétés** : id, baesId, typeErreur, timestamp, isSolved, isIgnored, acknowledgedBy, acknowledgedAt, updatedAt
- **Relations** : Appartient à un Baes

### 7. Coords
Représente des coordonnées géographiques.
- **Propriétés** : lat1, lng1, lat2, lng2 (définissant une zone rectangulaire)

## Modèles d'utilisateurs

### 8. Utilisateur
Représente un utilisateur du système.
- **Propriétés** : id, login, sites (liste de SiteAssociation), globalRolesList
- **Relations** : Peut être associé à plusieurs Sites via SiteAssociation, peut avoir des Roles globaux

### 9. SiteAssociation
Représente l'association entre un utilisateur et un site, avec des rôles spécifiques.
- **Propriétés** : id, name, roles (liste de Role)
- **Relations** : Appartient à un Utilisateur, contient des Roles

### 10. Role
Représente un rôle utilisateur dans le système.
- **Propriétés** : id, name
- **Relations** : Peut être associé à un Utilisateur globalement ou via SiteAssociation

Ces modèles forment une structure hiérarchique permettant de gérer les sites, bâtiments, étages et dispositifs BAES, ainsi que les utilisateurs et leurs permissions dans le système.
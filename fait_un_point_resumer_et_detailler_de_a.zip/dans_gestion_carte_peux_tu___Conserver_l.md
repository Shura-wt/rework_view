
# Solution pour conserver les polygon_points en mémoire

Après analyse du code, j'ai identifié plusieurs problèmes qui causent la perte des `polygon_points` lors de la gestion des cartes. Voici les solutions à mettre en œuvre :

## 1. Problème dans la gestion des données BAES

Lorsque vous appelez `/etages/:id/baes`, vous recevez uniquement les données des BAES sans les `polygon_points` du bâtiment. Ensuite, vous remplacez l'objet Etage entier, perdant ainsi les données de polygone.

### Solution : Fusionner les données au lieu de remplacer

Modifiez la méthode `getBaesByIdFloor` dans `BAES_api.dart` pour qu'elle mette à jour uniquement la liste des BAES dans l'étage existant :

```dart
static Future<List<Baes>> getBaesByIdFloor(int etageId) async {
  try {
    final response = await http.get(
      Uri.parse('$baseUrl/etages/$etageId/baes'),
      headers: {'Content-Type': 'application/json'},
    );

    if (response.statusCode == 200) {
      final List<dynamic> jsonData = jsonDecode(response.body);
      List<Baes> newBaes = jsonData.map((json) => Baes.fromJson(json)).toList();
      
      // Trouver l'étage existant qui contient déjà les polygon_points
      Etage? existingEtage = Etage.allEtages.firstWhere(
        (etage) => etage.id == etageId,
        orElse: () => null,
      );
      
      if (existingEtage != null) {
        // Mettre à jour uniquement la liste des BAES, pas l'objet entier
        int index = Etage.allEtages.indexOf(existingEtage);
        Etage updatedEtage = Etage(
          id: existingEtage.id,
          name: existingEtage.name,
          batimentId: existingEtage.batimentId,
          carte: existingEtage.carte,
          baes: newBaes,
        );
        Etage.allEtages[index] = updatedEtage;
      }
      
      return newBaes;
    } else {
      return [];
    }
  } catch (e) {
    return [];
  }
}
```

## 2. Alternative : Recharger les données complètes après mise à jour des BAES

Si la fusion n'est pas pratique, vous pouvez recharger les données complètes après avoir mis à jour les BAES :

```dart
// Après avoir appelé getBaesByIdFloor
await APIBatiment.getBuildingAllData(batimentId); // Recharge les données complètes
```

## 3. Correction du modèle Batiment pour gérer correctement polygon_points

Assurez-vous que la méthode `fromJson` de la classe `Batiment` traite correctement les `polygon_points` :

```dart
factory Batiment.fromJson(Map<String, dynamic> json) {
  var etagesList = <Etage>[];
  if (json['etages'] != null) {
    etagesList = (json['etages'] as List).map((e) => Etage.fromJson(e)).toList();
  }

  // Traitement correct des polygon_points
  dynamic polygonPoints;
  if (json['polygon_points'] != null) {
    polygonPoints = json['polygon_points'];
  } else {
    polygonPoints = {};
  }

  return Batiment(
    id: json['id'] ?? 0,
    name: json['name'] ?? '',
    polygonPoints: polygonPoints,
    siteId: json['site_id'],
    etages: etagesList,
  );
}
```

## 4. Correction de la construction des layers dans FlutterMap

Assurez-vous que lorsque vous mettez à jour les marqueurs BAES, vous ne remplacez pas toutes les couches du FlutterMap. Voici comment structurer correctement les layers :

```dart
FlutterMap(
  options: MapOptions(...),
  children: [
    // Couche d'image de fond (toujours présente)
    OverlayImageLayer(...),
    
    // Couche de polygones (toujours présente, même si vous mettez à jour les BAES)
    PolygonLayer(
      polygons: _buildPolygones(),
    ),
    
    // Couche de marqueurs (mise à jour avec les nouvelles données BAES)
    MarkerLayer(
      markers: floorMarkers,
    ),
  ],
)
```

## Résumé des modifications à apporter

1. **Ne remplacez pas l'objet Etage entier** lorsque vous récupérez uniquement les BAES
2. **Fusionnez les nouvelles données BAES** dans l'objet Etage existant
3. **Ou rechargez les données complètes** après avoir mis à jour les BAES
4. **Assurez-vous que le modèle Batiment** traite correctement les polygon_points
5. **Conservez toutes les couches** dans le FlutterMap lors de la mise à jour des marqueurs

Ces modifications garantiront que les `polygon_points` sont conservés en mémoire et que les polygones restent affichés sur la carte, même après avoir mis à jour les données BAES.
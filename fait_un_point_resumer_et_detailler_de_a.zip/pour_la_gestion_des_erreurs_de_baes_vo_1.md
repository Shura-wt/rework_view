
# Implementation of BAES Error Management System

Based on the requirements, I'll implement a system to manage BAES errors with the following features:
- Fetch all errors at startup
- Poll for new errors every 5 seconds
- Update BAES status on the cards when new errors appear

## 1. Create a new ErrorApi class

First, create a new file `lib/services/api/erreur_api.dart` with the following content:

```dart
part of "../../main.dart";

class ErreurApi {
  static String baseUrl = Config.baseUrl;
  
  /// Récupère toutes les erreurs
  static Future<List<HistoriqueErreur>> getAllErrors() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/erreurs/'),
        headers: {'Content-Type': 'application/json'},
      );
      
      if (response.statusCode == 200) {
        final List<dynamic> jsonData = jsonDecode(response.body);
        return jsonData.map((json) => HistoriqueErreur.fromJson(json)).toList();
      } else {
        return [];
      }
    } catch (e) {
      if (kDebugMode) {
        print("Erreur lors de la récupération des erreurs: $e");
      }
      return [];
    }
  }
  
  /// Récupère les erreurs après un ID spécifique
  static Future<List<HistoriqueErreur>> getErrorsAfter(int errorId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/erreurs/after/$errorId'),
        headers: {'Content-Type': 'application/json'},
      );
      
      if (response.statusCode == 200) {
        final List<dynamic> jsonData = jsonDecode(response.body);
        return jsonData.map((json) => HistoriqueErreur.fromJson(json)).toList();
      } else {
        return [];
      }
    } catch (e) {
      if (kDebugMode) {
        print("Erreur lors de la récupération des nouvelles erreurs: $e");
      }
      return [];
    }
  }
  
  /// Récupère les erreurs pour un BAES spécifique
  static Future<List<HistoriqueErreur>> getErrorsForBaes(int baesId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/erreurs/baes/$baesId'),
        headers: {'Content-Type': 'application/json'},
      );
      
      if (response.statusCode == 200) {
        final List<dynamic> jsonData = jsonDecode(response.body);
        return jsonData.map((json) => HistoriqueErreur.fromJson(json)).toList();
      } else {
        return [];
      }
    } catch (e) {
      if (kDebugMode) {
        print("Erreur lors de la récupération des erreurs du BAES: $e");
      }
      return [];
    }
  }
  
  /// Acquitte une erreur (marque comme résolu/ignoré)
  static Future<bool> acknowledgeError(int errorId, bool isSolved, bool isIgnored) async {
    try {
      final Map<String, dynamic> data = {
        'is_solved': isSolved,
        'is_ignored': isIgnored,
      };
      
      final response = await http.put(
        Uri.parse('$baseUrl/erreurs/$errorId/status'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(data),
      );
      
      return response.statusCode == 200;
    } catch (e) {
      if (kDebugMode) {
        print("Erreur lors de l'acquittement de l'erreur: $e");
      }
      return false;
    }
  }
}
```

## 2. Update the main.dart file to include the new part

Add the following line to the main.dart file in the API section:

```dart
part 'services/api/erreur_api.dart';
```

## 3. Modify the ViewCartePage class to implement error polling

Update the `_ViewCartePageState` class in `lib/pages/view_carte_page.dart`:

```dart
class _ViewCartePageState extends State<ViewCartePage> {
  // Existing code...
  
  // Add these new variables
  Timer? _errorPollingTimer;
  int _lastKnownErrorId = 0;
  List<HistoriqueErreur> _allErrors = [];
  
  @override
  void initState() {
    super.initState();
    // Existing code...
    
    // Initialize error polling
    _initializeErrorPolling();
  }
  
  @override
  void dispose() {
    // Cancel the timer when the widget is disposed
    _errorPollingTimer?.cancel();
    super.dispose();
  }
  
  /// Initialize error polling system
  Future<void> _initializeErrorPolling() async {
    // First, get all errors
    await _fetchAllErrors();
    
    // Then set up a timer to poll for new errors every 5 seconds
    _errorPollingTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      _fetchNewErrors();
    });
  }
  
  /// Fetch all errors at startup
  Future<void> _fetchAllErrors() async {
    final errors = await ErreurApi.getAllErrors();
    
    if (errors.isNotEmpty) {
      setState(() {
        _allErrors = errors;
        // Get the highest error ID
        _lastKnownErrorId = errors.map((e) => e.id).reduce((a, b) => a > b ? a : b);
      });
      
      // Update BAES status with these errors
      _updateBaesStatus(errors);
    }
  }
  
  /// Fetch new errors (after the last known error ID)
  Future<void> _fetchNewErrors() async {
    if (_lastKnownErrorId > 0) {
      final newErrors = await ErreurApi.getErrorsAfter(_lastKnownErrorId);
      
      if (newErrors.isNotEmpty) {
        setState(() {
          _allErrors.addAll(newErrors);
          // Update the last known error ID
          _lastKnownErrorId = newErrors.map((e) => e.id).reduce((a, b) => a > b ? a : b);
        });
        
        // Update BAES status with these new errors
        _updateBaesStatus(newErrors);
      }
    }
  }
  
  /// Update BAES status based on errors
  void _updateBaesStatus(List<HistoriqueErreur> errors) {
    // Group errors by BAES ID
    final Map<int, List<HistoriqueErreur>> errorsByBaes = {};
    
    for (var error in errors) {
      if (!errorsByBaes.containsKey(error.baesId)) {
        errorsByBaes[error.baesId] = [];
      }
      errorsByBaes[error.baesId]!.add(error);
    }
    
    // Update each BAES with its errors
    for (var baesId in errorsByBaes.keys) {
      // Find the BAES in the allBaes list
      final baesIndex = Baes.allBaes.indexWhere((b) => b.id == baesId);
      
      if (baesIndex >= 0) {
        // Create a new BAES with updated errors
        final baes = Baes.allBaes[baesIndex];
        final updatedBaes = Baes(
          id: baes.id,
          name: baes.name,
          position: baes.position,
          etageId: baes.etageId,
          erreurs: errorsByBaes[baesId]!,
        );
        
        // Replace the old BAES with the updated one
        Baes.allBaes[baesIndex] = updatedBaes;
      }
    }
    
    // Refresh the UI if we're in floor view
    if (isFloorView) {
      _loadFloorMap(currentBuilding, currentFloor);
    }
  }
  
  // Rest of the existing code...
}
```

## 4. Update the HistoriqueErreur model to include status fields

Modify the `HistoriqueErreur` class in `lib/models/historique_erreur.dart` to include the status fields:

```dart
class HistoriqueErreur {
  final int id;
  final int baesId;
  final String typeErreur;
  final DateTime timestamp;
  final bool isSolved;
  final bool isIgnored;
  final String? acknowledgedBy;
  final DateTime? acknowledgedAt;

  HistoriqueErreur({
    required this.id,
    required this.baesId,
    required this.typeErreur,
    required this.timestamp,
    this.isSolved = false,
    this.isIgnored = false,
    this.acknowledgedBy,
    this.acknowledgedAt,
  });

  factory HistoriqueErreur.fromJson(Map<String, dynamic> json) {
    // Handle null or missing values with default values
    final id = json['id'] ?? 0;
    final baesId = json['baes_id'] ?? 0;
    final typeErreur = json['type_erreur'] ?? 'unknown';
    final isSolved = json['is_solved'] ?? false;
    final isIgnored = json['is_ignored'] ?? false;
    final acknowledgedBy = json['acknowledged_by'];

    // Handle timestamp parsing with error handling
    DateTime timestamp;
    try {
      timestamp = json['timestamp'] != null 
          ? DateTime.parse(json['timestamp']) 
          : DateTime.now();
    } catch (e) {
      // If parsing fails, use current time as fallback
      timestamp = DateTime.now();
    }

    // Handle acknowledged_at parsing
    DateTime? acknowledgedAt;
    try {
      acknowledgedAt = json['acknowledged_at'] != null 
          ? DateTime.parse(json['acknowledged_at']) 
          : null;
    } catch (e) {
      acknowledgedAt = null;
    }

    final erreur = HistoriqueErreur(
      id: id,
      baesId: baesId,
      typeErreur: typeErreur,
      timestamp: timestamp,
      isSolved: isSolved,
      isIgnored: isIgnored,
      acknowledgedBy: acknowledgedBy,
      acknowledgedAt: acknowledgedAt,
    );

    return erreur;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'baes_id': baesId,
      'type_erreur': typeErreur,
      'timestamp': timestamp.toIso8601String(),
      'is_solved': isSolved,
      'is_ignored': isIgnored,
      'acknowledged_by': acknowledgedBy,
      'acknowledged_at': acknowledgedAt?.toIso8601String(),
    };
  }
}
```

## 5. Add error acknowledgment functionality to the UI

You can add a button to acknowledge errors in the error display UI. For example, in the `ErrorBAESTile` widget:

```dart
class ErrorBAESTile extends StatelessWidget {
  final Baes baes;

  const ErrorBAESTile({super.key, required this.baes});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.red.shade100,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "BAES: ${baes.name}",
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ...baes.erreurs.map((error) => _buildErrorItem(context, error)).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorItem(BuildContext context, HistoriqueErreur error) {
    String errorType = error.typeErreur == 'connection'
        ? 'Erreur de connexion'
        : error.typeErreur == 'battery'
            ? 'Erreur de batterie'
            : 'Erreur inconnue';

    String status = error.isSolved
        ? 'Résolu'
        : error.isIgnored
            ? 'Ignoré'
            : 'Non traité';

    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Type: $errorType"),
                Text("Date: ${error.timestamp.toString().substring(0, 16)}"),
                Text("Statut: $status"),
                if (error.acknowledgedBy != null)
                  Text("Acquitté par: ${error.acknowledgedBy}"),
              ],
            ),
          ),
          if (!error.isSolved && !error.isIgnored)
            Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.check, color: Colors.green),
                  onPressed: () => _acknowledgeError(context, error, true, false),
                  tooltip: 'Marquer comme résolu',
                ),
                IconButton(
                  icon: const Icon(Icons.block, color: Colors.orange),
                  onPressed: () => _acknowledgeError(context, error, false, true),
                  tooltip: 'Ignorer',
                ),
              ],
            ),
        ],
      ),
    );
  }

  Future<void> _acknowledgeError(
      BuildContext context, HistoriqueErreur error, bool isSolved, bool isIgnored) async {
    final success = await ErreurApi.acknowledgeError(error.id, isSolved, isIgnored);
    
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isSolved ? 'Erreur marquée comme résolue' : 'Erreur ignorée',
          ),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Échec de l\'acquittement de l\'erreur'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}
```

## Summary

This implementation:

1. Creates a new `ErreurApi` class with methods to interact with the error management API endpoints
2. Updates the `HistoriqueErreur` model to include status fields
3. Implements error polling in the `ViewCartePage` class:
   - Fetches all errors at startup
   - Sets up a timer to poll for new errors every 5 seconds
   - Updates BAES status when new errors are detected
4. Adds UI components to display and acknowledge errors

The system will automatically update the BAES status on the cards whenever new errors are detected, ensuring that the UI always reflects the current state of the BAES devices.
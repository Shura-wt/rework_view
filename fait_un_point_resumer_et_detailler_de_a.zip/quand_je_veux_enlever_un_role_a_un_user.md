
```markdown
# Correction du problème de suppression des rôles utilisateur

J'ai identifié le problème qui empêche la suppression des rôles lorsqu'ils sont désélectionnés dans l'interface utilisateur. Le problème est lié à la façon dont le code traite les données renvoyées par l'API.

## Problème identifié

En analysant les logs, j'ai constaté que:

1. L'API renvoie correctement les rôles existants de l'utilisateur dans un format comme celui-ci:
   ```json
   {
     "is_global": true,
     "roles": [
       { "role_id": 1, "role_name": "user" },
       { "role_id": 2, "role_name": "technicien" },
       { "role_id": 4, "role_name": "super-admin" }
     ],
     "site_id": null,
     "site_name": "Global"
   }
   ```

2. Cependant, le code actuel tente d'accéder directement à un champ `role_id` qui n'existe pas dans cette structure:
   ```dart
   if (association['site_id'] == null && association['role_id'] != null) {
     // Ce code ne fonctionne pas car role_id n'existe pas à ce niveau
   }
   ```

3. C'est pourquoi les logs montrent:
   ```
   Association: user_id=null, site_id=null, role_id=null
   ```

## Solution

Voici la correction à apporter au code dans `gestion_utilisateurs.dart` pour traiter correctement les rôles globaux:

1. Modifier la façon dont les rôles globaux existants sont collectés (vers la ligne 290):

```dart
// Étape 4: Ajouter les rôles globaux
// Vérifier les rôles globaux existants pour éviter les doublons
Set<int> existingGlobalRoleIds = {};
for (final association in existingAssociations) {
  // Les rôles globaux ont site_id à null
  if (association['site_id'] == null && association['roles'] != null) {
    // Parcourir le tableau de rôles
    final rolesList = association['roles'] as List<dynamic>;
    for (final roleInfo in rolesList) {
      if (roleInfo is Map<String, dynamic> && roleInfo['role_id'] != null) {
        existingGlobalRoleIds.add(roleInfo['role_id'] as int);
      }
    }
  }
}
print('Rôles globaux existants: $existingGlobalRoleIds');
```

2. Modifier la section qui supprime les rôles globaux (vers la ligne 356):

```dart
// Étape 5b: Supprimer les rôles globaux qui ne sont plus nécessaires
for (final association in existingAssociations) {
  // Les rôles globaux ont site_id à null
  if (association['site_id'] == null && association['roles'] != null) {
    final rolesList = association['roles'] as List<dynamic>;
    for (final roleInfo in rolesList) {
      if (roleInfo is Map<String, dynamic> && roleInfo['role_id'] != null) {
        final userId = updatedUser.id; // Utiliser l'ID de l'utilisateur en cours de modification
        final roleId = roleInfo['role_id'] as int;
        final roleName = roleInfo['role_name'] as String;

        // Vérifier si ce rôle global est toujours sélectionné (en tenant compte de la casse)
        if (!roles.map((r) => r.toLowerCase()).contains(roleName.toLowerCase())) {
          try {
            // Supprimer le rôle global car il n'est plus sélectionné
            print('Suppression du rôle global: $roleName (ID: $roleId)');
            await UtilisateurApi.deleteUserGlobalRole(
              userId: userId,
              roleId: roleId,
            );
            print('Rôle global $roleName (ID: $roleId) supprimé avec succès');
          } catch (e) {
            // Enregistrer l'erreur mais continuer
            failedOperations.add('Suppression rôle global: $roleName');
            print('Erreur lors de la suppression du rôle global $roleName (ID: $roleId): $e');
          }
        }
      }
    }
  }
}
```

Cette solution corrige le problème en:
1. Accédant correctement au tableau `roles` dans les associations
2. Extrayant les IDs de rôle de chaque élément du tableau
3. Comparant les noms de rôle de manière insensible à la casse pour éviter les problèmes de majuscules/minuscules
4. Utilisant l'ID de l'utilisateur en cours de modification pour la suppression

Avec ces modifications, le système pourra correctement supprimer les rôles qui ont été désélectionnés dans l'interface utilisateur.
```
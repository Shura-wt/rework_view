### Objectif
Dans le mode Bâtiment, vous voulez:
- Afficher un menu déroulant (dropdown) listant tous les étages du bâtiment, avec options de tri.
- Afficher par défaut la carte + informations du premier étage (selon le tri courant).
- Permettre de changer d’étage en sélectionnant un autre élément dans le dropdown.
- Garder les BAES à jour automatiquement via votre LatestStatusPoller.

Ci-dessous une implémentation modulable qui s’intègre à l’architecture « un seul FlutterMap + MapMode » proposée précédemment.

---

### Tri des étages
Définissez les critères et une fonction utilitaire de tri.

```dart
enum FloorSort { byLevelAsc, byLevelDesc, byNameAsc }

extension FloorSortX on FloorSort {
  String get label {
    switch (this) {
      case FloorSort.byLevelAsc:  return 'Niveau ↑';
      case FloorSort.byLevelDesc: return 'Niveau ↓';
      case FloorSort.byNameAsc:   return 'Nom A→Z';
    }
  }
}

List<Floor> sortFloors(List<Floor> floors, FloorSort sort) {
  final list = List<Floor>.from(floors);
  switch (sort) {
    case FloorSort.byLevelAsc:
      list.sort((a, b) => a.level.compareTo(b.level));
      break;
    case FloorSort.byLevelDesc:
      list.sort((a, b) => b.level.compareTo(a.level));
      break;
    case FloorSort.byNameAsc:
      list.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
      break;
  }
  return list;
}
```

Note: `Floor` est un modèle minimal attendu: `{ id, buildingId, name, level, polygon?, baes[]? }`. Adaptez le code à vos attributs réels.

---

### BuildingModeView: dropdown + tri + sélection initiale du 1er étage
Ce widget gère le tri et la sélection d’étage. Il bascule le `MapMode` en Floor lors de la sélection et affiche la vue associée.

```dart
class BuildingModeView extends StatefulWidget {
  final int buildingId;
  const BuildingModeView({super.key, required this.buildingId});

  @override
  State<BuildingModeView> createState() => _BuildingModeViewState();
}

class _BuildingModeViewState extends State<BuildingModeView> {
  FloorSort _sort = FloorSort.byLevelAsc;
  int? _selectedFloorId;
  late List<Floor> _floors;

  @override
  void initState() {
    super.initState();
    _loadFloorsAndInit();
  }

  @override
  void didUpdateWidget(covariant BuildingModeView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.buildingId != widget.buildingId) {
      _loadFloorsAndInit();
    }
  }

  void _loadFloorsAndInit() {
    _floors = buildingRepo.getFloors(widget.buildingId); // impl. à fournir
    _applySort(selectFirst: true);
  }

  void _applySort({bool selectFirst = false}) {
    _floors = sortFloors(_floors, _sort);
    if (_floors.isNotEmpty && (selectFirst || _selectedFloorId == null)) {
      _selectFloor(_floors.first.id);
    } else {
      setState(() {}); // rafraîchir l’UI (p.ex. étiquette de tri)
    }
  }

  void _selectFloor(int floorId) {
    setState(() {
      _selectedFloorId = floorId;
    });
    // Bascule en mode étage → la carte adapte ses couches
    final mapState = context.read<MapViewState>();
    mapState.setMode(MapMode.floor(widget.buildingId, floorId));
  }

  @override
  Widget build(BuildContext context) {
    final building = buildingRepo.getById(widget.buildingId);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                building?.name ?? 'Bâtiment #${widget.buildingId}',
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ),
            PopupMenuButton<FloorSort>(
              tooltip: 'Trier les étages',
              onSelected: (s) {
                setState(() => _sort = s);
                _applySort(selectFirst: false);
              },
              itemBuilder: (_) => [
                for (final s in FloorSort.values)
                  PopupMenuItem(
                    value: s,
                    child: Row(
                      children: [
                        Icon(
                          s == _sort ? Icons.radio_button_checked : Icons.radio_button_unchecked,
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Text(s.label),
                      ],
                    ),
                  ),
              ],
              child: Row(
                children: [
                  const Icon(Icons.sort),
                  const SizedBox(width: 6),
                  Text(_sort.label),
                ],
              ),
            ),
            const SizedBox(width: 12),
            DropdownButton<int>(
              value: _selectedFloorId,
              hint: const Text('Choisir un étage'),
              items: _floors.map((f) => DropdownMenuItem<int>(
                    value: f.id,
                    child: Text('${f.name} (Niv. ${f.level})'),
                  ))
                  .toList(),
              onChanged: (v) { if (v != null) _selectFloor(v); },
            ),
          ],
        ),
        const SizedBox(height: 8),
        Expanded(
          child: _selectedFloorId == null
              ? const Center(child: Text('Aucun étage disponible'))
              : FloorView(buildingId: widget.buildingId, floorId: _selectedFloorId!),
        ),
      ],
    );
  }
}
```

---

### FloorView: carte de l’étage + panneau d’infos
Vous pouvez afficher la carte à gauche et un panneau d’informations (liste BAES, stats) à droite.

```dart
class FloorView extends StatelessWidget {
  final int buildingId;
  final int floorId;
  const FloorView({super.key, required this.buildingId, required this.floorId});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(flex: 3, child: SmartMapForFloor(floorId: floorId)),
        const SizedBox(width: 12),
        Expanded(flex: 2, child: FloorSidePanel(floorId: floorId)),
      ],
    );
  }
}
```

---

### SmartMapForFloor: polygone d’étage + BAES réactifs
Rendu de la carte pour l’étage sélectionné avec mise à jour fine des marqueurs BAES.

```dart
class SmartMapForFloor extends StatelessWidget {
  final int floorId;
  const SmartMapForFloor({super.key, required this.floorId});

  @override
  Widget build(BuildContext context) {
    final polygon = floorRepository.getPolygon(floorId); // impl. à fournir
    final baes = floorRepository.getBaesForFloor(floorId); // liste BAES {id, position}
    final mapController = context.read<MapController>(); // si vous partagez un MapController

    return FlutterMap(
      mapController: mapController,
      options: MapOptions(
        onMapReady: () {
          if (polygon != null) {
            final b = LatLngBounds.fromPoints(polygon.points);
            mapController.fitBounds(b, options: const FitBoundsOptions(padding: EdgeInsets.all(24)));
          }
        },
      ),
      children: [
        TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'),
        if (polygon != null) PolygonLayer(polygons: [polygon]),
        MarkerLayer(
          markers: baes.map((b) {
            final notifier = LatestStatusPoller.instance.getNotifierFor(b.id);
            return Marker(
              point: b.position,
              width: 36,
              height: 36,
              builder: (ctx) => ValueListenableBuilder<BaeStatus?>(
                valueListenable: notifier,
                builder: (ctx, status, _) {
                  final color = _statusToColor(status);
                  return _BaesDot(color: color, id: b.id); // widget léger personnalisable
                },
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Color _statusToColor(BaeStatus? s) {
    if (s == null) return Colors.grey;
    switch (LatestStatusPoller.errorCodeToLabel(s.erreur ?? -1)) {
      case 'ok': return Colors.green;
      case 'erreur_batterie': return Colors.orange;
      case 'erreur_connexion': return Colors.red;
      default: return Colors.blueGrey;
    }
  }
}
```

---

### Panneau d’étage: liste BAES filtrée
S’appuie sur `perBaesNotifier` pour ne lister que les BAES de l’étage courant.

```dart
class FloorSidePanel extends StatelessWidget {
  final int floorId;
  const FloorSidePanel({super.key, required this.floorId});

  @override
  Widget build(BuildContext context) {
    final ids = floorRepository.getBaesForFloor(floorId).map((b) => b.id).toSet();
    final poller = LatestStatusPoller.instance;
    return ValueListenableBuilder<Map<int, BaeStatus>>(
      valueListenable: poller.perBaesNotifier,
      builder: (context, map, _) {
        final entries = map.entries
            .where((e) => ids.contains(e.key))
            .toList()
          ..sort((a, b) {
            final au = (a.value.updatedAt ?? a.value.timestamp) ?? DateTime.fromMillisecondsSinceEpoch(0);
            final bu = (b.value.updatedAt ?? b.value.timestamp) ?? DateTime.fromMillisecondsSinceEpoch(0);
            return bu.compareTo(au);
          });

        if (entries.isEmpty) {
          return const Center(child: Text('Aucun BAES sur cet étage'));
        }

        return ListView.builder(
          itemCount: entries.length,
          itemBuilder: (ctx, i) {
            final id = entries[i].key;
            final s = entries[i].value;
            final color = _statusToColor(s);
            return ListTile(
              dense: true,
              leading: Icon(Icons.lightbulb, color: color),
              title: Text('BAES #$id'),
              subtitle: Text('MAJ: ${(s.updatedAt ?? s.timestamp) ?? '-'}'),
            );
          },
        );
      },
    );
  }

  Color _statusToColor(BaeStatus s) {
    switch (LatestStatusPoller.errorCodeToLabel(s.erreur ?? -1)) {
      case 'ok': return Colors.green;
      case 'erreur_batterie': return Colors.orange;
      case 'erreur_connexion': return Colors.red;
      default: return Colors.blueGrey;
    }
  }
}
```

---

### Intégration avec votre page et MapMode
- En SiteMode: clic sur polygone bâtiment → `MapMode.building(buildingId)`
- BuildingModeView initialise la liste d’étages (tri) → sélection automatique du 1er → `MapMode.floor(buildingId, floorId)`
- La carte/liste s’actualise automatiquement via les `ValueNotifier` du poller.

Exemple d’aiguillage dans votre page principale:

```dart
@override
Widget build(BuildContext context) {
  final mapState = context.watch<MapViewState>();

  Widget body;
  switch (mapState.mode.type) {
    case MapModeType.site:
      body = const SiteModeView();
      break;
    case MapModeType.building:
      body = BuildingModeView(buildingId: mapState.mode.buildingId!);
      break;
    case MapModeType.floor:
      body = FloorView(
        buildingId: mapState.mode.buildingId!,
        floorId: mapState.mode.floorId!,
      );
      break;
    case MapModeType.edit:
      body = EditModeView(
        buildingId: mapState.mode.buildingId,
        floorId: mapState.mode.floorId,
      );
      break;
  }

  return Scaffold(
    body: SafeArea(child: Padding(padding: const EdgeInsets.all(12.0), child: body)),
    floatingActionButton: VersatileFabColumn(
      fabs: [
        VersatileFab.icon(
          onPressed: () => mapState.setMode(const MapMode.site()),
          icon: Icons.arrow_back,
          tooltip: 'Retour',
        ),
      ],
    ),
  );
}
```

---

### Bonnes pratiques
- Démarrer `LatestStatusPoller.instance.start()` une seule fois (par exemple dans `initState` de votre page principale) pour alimenter la carte et les listes.
- Garder un seul `MapController` partagé et des layers dynamiques pour éviter de recharger les tuiles.
- Utiliser `getNotifierFor(baesId)` pour des mises à jour fines des marqueurs, sans rebuild de toute la couche.
- Mémoriser le tri choisi (via SharedPreferences) si vous voulez retrouver la préférence à la réouverture.

---

### Checklist
1) Implémenter `FloorSort` + `sortFloors`.
2) Ajouter `BuildingModeView` qui gère tri + dropdown + sélection initiale.
3) Router en `MapMode.floor` lors d’un changement d’étage.
4) Rendre la carte (`SmartMapForFloor`) avec polygone d’étage et marqueurs BAES réactifs.
5) Ajouter un panneau d’infos (`FloorSidePanel`) branché sur `perBaesNotifier` et filtré par étage.
6) Vérifier que le poller tourne (start une seule fois) et que la navigation de modes est fluide.

Si vous partagez vos modèles exacts `Building`/`Floor` et la version `flutter_map`, je peux adapter les signatures et fournir l’implémentation précise du polygone d’étage (`_buildFloorPolygon`) et des interactions de clic sur polygones de bâtiments.
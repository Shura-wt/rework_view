# Application BAES Front : Résumé Détaillé

## Objectif de l'Application

L'application BAES Front est une solution de gestion et de surveillance des Blocs Autonomes d'Éclairage de Sécurité (BAES) dans différents sites, bâtiments et étages. Elle permet de visualiser, surveiller et gérer l'état des dispositifs d'éclairage de sécurité, ainsi que de traiter les erreurs qui peuvent survenir sur ces équipements.

## Architecture Technique

L'application est développée avec Flutter, un framework de développement d'applications multiplateformes. Elle utilise:
- Une architecture basée sur le modèle Provider pour la gestion d'état
- Des repositories pour l'accès aux données
- Des services API pour la communication avec le backend
- Des modèles de données structurés hiérarchiquement

## Modèles de Données

L'application s'organise autour d'une hiérarchie de modèles:

1. **Site**: Représente un campus ou un site contenant plusieurs bâtiments
   - Propriétés: id, name, batiments, carte (optionnelle)

2. **Batiment**: Représente un bâtiment au sein d'un site
   - Propriétés: id, name, polygonPoints (contour du bâtiment), siteId, étages

3. **Etage**: Représente un étage dans un bâtiment
   - Propriétés: id, name, batimentId, carte (optionnelle), baes (liste de BAES)

4. **BAES**: Représente un bloc autonome d'éclairage de sécurité
   - Propriétés: id, name, position, etageId, erreurs (historique)

5. **HistoriqueErreur**: Représente les erreurs survenues sur un BAES
   - Propriétés: id, baesId, typeErreur, timestamp, isSolved, isIgnored, etc.

6. **Carte**: Représente une carte ou un plan d'étage/site
   - Propriétés: id, chemin, etageId/siteId, centerLat, centerLng, zoom

7. **Utilisateur**: Représente un utilisateur du système
   - Propriétés: id, login, sites (associations), globalRolesList

8. **Role**: Définit les permissions des utilisateurs
   - Propriétés: id, name

## Fonctionnalités Principales

### 1. Authentification et Gestion des Utilisateurs
- Système de login sécurisé
- Gestion des rôles et permissions (admin, super-admin, etc.)
- Association des utilisateurs à des sites spécifiques avec des rôles dédiés

### 2. Visualisation Cartographique
- Affichage des sites, bâtiments et étages sur des cartes interactives
- Utilisation de flutter_map pour l'intégration cartographique
- Positionnement géographique des BAES sur les plans d'étage

### 3. Gestion des BAES
- Visualisation de l'état des BAES en temps réel
- Suivi des erreurs et dysfonctionnements
- Historique des problèmes et de leur résolution

### 4. Administration
- Gestion des cartes et plans (upload, positionnement)
- Gestion des utilisateurs et de leurs permissions
- Configuration des sites, bâtiments et étages

### 5. Surveillance et Alertes
- Suivi des erreurs sur les BAES
- Système d'acquittement des erreurs
- Marquage des problèmes comme résolus ou ignorés

## Pages et Navigation

L'application comporte plusieurs pages principales:

1. **LoginPage**: Page d'authentification
   - Permet aux utilisateurs de se connecter avec leurs identifiants

2. **HomePage**: Page d'accueil principale
   - Centre de contrôle pour accéder aux différentes fonctionnalités
   - Peut afficher différents contenus selon le paramètre initialPage

3. **VisualisationCartePage**: Page de visualisation des cartes
   - Affiche les plans des sites, bâtiments et étages
   - Permet de visualiser les BAES sur les plans

4. **Pages d'administration**:
   - Gestion des utilisateurs: Création, modification et suppression d'utilisateurs
   - Gestion des cartes: Upload et configuration des plans

## Système de Sécurité

L'application implémente un système de garde-route (AuthGuard) qui:
- Vérifie l'authentification des utilisateurs
- Contrôle l'accès aux pages en fonction des rôles
- Redirige vers la page de login si nécessaire

## Fonctionnement Technique

1. **Initialisation**: L'application démarre avec plusieurs providers (AuthProvider, SiteProvider, BaesProvider, ErreurProvider)

2. **Flux de données**:
   - Les repositories communiquent avec les API pour récupérer les données
   - Les providers notifient les widgets des changements de données
   - Les widgets se reconstruisent pour afficher les données à jour

3. **Mise en cache**:
   - Système de cache pour optimiser les performances
   - Durée de validité du cache configurable (5 minutes par défaut)

4. **Communication API**:
   - Utilisation de HTTP pour les requêtes au backend
   - Gestion des erreurs et des tentatives de reconnexion

## Conclusion

L'application BAES Front est une solution complète pour la gestion des blocs d'éclairage de sécurité, offrant une interface utilisateur intuitive et des fonctionnalités avancées de surveillance et d'administration. Sa structure hiérarchique (Site > Bâtiment > Étage > BAES) permet une organisation claire des données et une navigation intuitive pour les utilisateurs.
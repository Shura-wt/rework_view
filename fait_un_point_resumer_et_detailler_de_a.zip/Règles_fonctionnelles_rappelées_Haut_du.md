### Objectif
Implémenter un LeftDrawer complet conforme à vos règles:
- Dropdown des sites de l’utilisateur; bouton admin/superadmin pour créer/renommer/supprimer un site.
- Deux cases à cocher (connexion=0, batterie=4) avec logique de filtre:
  - Aucune cochée: seulement OK(6) et inconnus
  - Une seule cochée: uniquement ce type d’erreur
  - Les deux cochées: tout (0, 4, 6, inconnus)
- Trois tuiles: Liste, Erreurs, Non placé, avec filtres appliqués.
- “Erreurs”: au plus 3 lignes par BAES (connexion, batterie, OK) et boutons Ignorer/Acquitter sur lignes non-OK.

---

### Code prêt à coller (remplacez lib\components\drawer.dart)

```dart
part of '../main.dart';

class LeftDrawer extends StatefulWidget {
  const LeftDrawer({super.key});

  @override
  State<LeftDrawer> createState() => _LeftDrawerState();
}

class _LeftDrawerState extends State<LeftDrawer> {
  final _sitesApi = SitesApi(SessionManager.instance.client);
  final _statusApi = StatusApi(SessionManager.instance.client);

  // État
  List<SiteLite> _sites = const [];
  SiteLite? _selectedSite;
  Site? _siteFull;

  Map<int, BaeStatus> _latestByBaes = const {}; // cache latest par baesId

  bool _loading = true;
  Object? _error;

  // Filtres (0=connexion, 4=batterie)
  bool _showConnection = true;
  bool _showBattery = true;

  // TODO: Branchez votre logique réelle de rôles
  bool get _isAdminLike {
    // Exemple:
    // final user = context.watch<UserProvider?>()?.user;
    // return user?.roles.contains('admin') == true || user?.roles.contains('superadmin') == true;
    return true;
  }

  @override
  void initState() {
    super.initState();
    _initData();
  }

  Future<void> _initData() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      // 1) Sites accessibles
      final sites = await _sitesApi.list();
      _sites = sites;
      _selectedSite ??= sites.isNotEmpty ? sites.first : null;

      // 2) Site complet
      if (_selectedSite != null) {
        await _loadSiteFull(_selectedSite!.id);
      }

      // 3) Derniers statuts pour fallback / affichage
      final latest = await _statusApi.latest();
      _latestByBaes = {
        for (final st in latest)
          if (st.baesId != null) st.baesId!: st,
      };

      setState(() => _loading = false);
    } catch (e) {
      setState(() {
        _error = e;
        _loading = false;
      });
    }
  }

  Future<void> _loadSiteFull(int siteId) async {
    // TODO: Branchez votre endpoint réel qui retourne un Site complet
    // Exemple:
    // final site = await SitesDetailsApi(SessionManager.instance.client).getFull(siteId);
    // setState(() => _siteFull = site);
    throw UnimplementedError('Implémentez _loadSiteFull avec votre endpoint /sites/{id}/full (Site complet)');
  }

  void _onSiteChanged(SiteLite? site) async {
    if (site == null) return;
    setState(() {
      _selectedSite = site;
      _siteFull = null;
      _loading = true;
      _error = null;
    });
    try {
      await _loadSiteFull(site.id);
      setState(() => _loading = false);
    } catch (e) {
      setState(() {
        _error = e;
        _loading = false;
      });
    }
  }

  // Helpers statut
  BaeStatus? _activeStatusFor(Baes b) {
    return b.latestStatus ?? _latestByBaes[b.id] ?? _mostRecent(b.statuses);
  }

  BaeStatus? _mostRecent(List<BaeStatus> statuses) {
    if (statuses.isEmpty) return null;
    statuses = List.of(statuses);
    statuses.sort((a, b) {
      final at = a.updatedAt ?? a.timestamp ?? DateTime.fromMillisecondsSinceEpoch(0);
      final bt = b.updatedAt ?? b.timestamp ?? DateTime.fromMillisecondsSinceEpoch(0);
      return bt.compareTo(at);
    });
    return statuses.first;
  }

  bool _isOkOrUnknown(int? code) {
    if (code == 6) return true;
    final info = StatusErrorVisuals.infoFor(code);
    return identical(info, StatusErrorVisuals.unknown);
  }

  // Règles filtres (au niveau BAES)
  // - Aucun coché: OK(6) + inconnus
  // - Un seul coché: seulement ce type (0 ou 4)
  // - Deux cochés: tout (0,4,6, inconnus)
  bool _baesPassesFilters(Baes b) {
    final st = _activeStatusFor(b);
    final code = st?.erreur;
    final isConn = code == 0;
    final isBatt = code == 4;
    if (!_showConnection && !_showBattery) return _isOkOrUnknown(code);
    if (_showConnection && _showBattery) return true;
    if (_showConnection) return isConn;
    if (_showBattery) return isBatt;
    return false;
  }

  // Pour la tuile "Erreurs": BAES qui ont des erreurs du type activé
  // Lignes: max 3 (connexion 0, batterie 4, OK 6)
  List<BaeStatus> _collectErrorLines(Baes b) {
    final active = _activeStatusFor(b);
    final hasConn = b.statuses.any((s) => s.erreur == 0) || active?.erreur == 0;
    final hasBatt = b.statuses.any((s) => s.erreur == 4) || active?.erreur == 4;

    bool appear;
    if (!_showConnection && !_showBattery) {
      appear = false; // pas d'erreur à lister
    } else if (_showConnection && _showBattery) {
      appear = hasConn || hasBatt;
    } else if (_showConnection) {
      appear = hasConn;
    } else {
      appear = hasBatt;
    }
    if (!appear) return const [];

    BaeStatus? pickFirst(int code) {
      final match = b.statuses.firstWhere(
        (s) => s.erreur == code,
        orElse: () => _activeStatusFor(b)?.erreur == code ? _activeStatusFor(b)! : (null as BaeStatus),
      );
      return match;
    }

    final conn = pickFirst(0);
    final batt = pickFirst(4);
    final ok = pickFirst(6);

    final lines = <BaeStatus>[];
    if (_showConnection && conn != null) lines.add(conn);
    if (_showBattery && batt != null) lines.add(batt);
    if ((_showConnection || _showBattery) && ok != null) lines.add(ok); // ajoute OK pour contexte

    return lines.take(3).toList(growable: false);
  }

  Future<void> _ignore(Baes b, int erreur) async {
    try {
      final updated = await _statusApi.updateBaesType(b.id, erreur, isIgnored: true);
      setState(() {
        _latestByBaes = Map<int, BaeStatus>.from(_latestByBaes)..[b.id] = updated;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erreur pendant Ignorer: $e')));
    }
  }

  Future<void> _ack(Baes b, int erreur) async {
    try {
      final updated = await _statusApi.updateBaesType(b.id, erreur, isSolved: true);
      setState(() {
        _latestByBaes = Map<int, BaeStatus>.from(_latestByBaes)..[b.id] = updated;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erreur pendant Acquitter: $e')));
    }
  }

  void _gotoGestionCarte() {
    Navigator.pop(context);
    Navigator.pushNamed(context, '/admin/carte');
  }

  // UI: Header
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Expanded(
            child: DropdownButton<SiteLite>(
              isExpanded: true,
              value: _selectedSite,
              hint: const Text('Choisir un site'),
              items: _sites
                  .map((s) => DropdownMenuItem(
                        value: s,
                        child: Text(s.name),
                      ))
                  .toList(),
              onChanged: _onSiteChanged,
            ),
          ),
          if (_isAdminLike)
            IconButton(
              tooltip: 'Gérer les sites',
              icon: const Icon(Icons.settings),
              onPressed: _openManageSitesDialog,
            ),
        ],
      ),
    );
  }

  // UI: Filtres
  Widget _buildFilters() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Column(
        children: [
          CheckboxListTile(
            value: _showConnection,
            onChanged: (v) => setState(() => _showConnection = v ?? false),
            title: const Text('Afficher status de connexion (erreur 0)'),
          ),
          CheckboxListTile(
            value: _showBattery,
            onChanged: (v) => setState(() => _showBattery = v ?? false),
            title: const Text('Afficher status de batterie (erreur 4)'),
          ),
          Align(
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.only(left: 12, bottom: 6),
              child: Text(
                (!_showConnection && !_showBattery)
                    ? 'Filtre: seulement OK (6) et inconnus'
                    : (_showConnection && _showBattery)
                        ? 'Filtre: tous les statuts (0, 4, 6, inconnus)'
                        : _showConnection
                            ? 'Filtre: erreurs connexion (0)'
                            : 'Filtre: erreurs batterie (4)',
                style: const TextStyle(color: Colors.grey),
              ),
            ),
          )
        ],
      ),
    );
  }

  // UI: Tuile "Liste"
  Widget _buildListeTile() {
    final site = _siteFull;
    if (site == null) return const SizedBox.shrink();

    return Card(
      margin: const EdgeInsets.all(12),
      child: ExpansionTile(
        initiallyExpanded: true,
        title: const Text('Liste'),
        children: site.batiments.map((bat) {
          final filteredEtages = bat.etages.map((etg) {
            final filteredBaes = etg.baes.where(_baesPassesFilters).toList();
            return (filteredBaes.isEmpty) ? null : (etg, filteredBaes);
          }).whereType<(Etage, List<Baes>)>().toList();

          if (filteredEtages.isEmpty) return const SizedBox.shrink();

          return ExpansionTile(
            title: Text(bat.name),
            children: filteredEtages.map((tuple) {
              final etg = tuple.$1;
              final baes = tuple.$2;
              return ExpansionTile(
                title: Text(etg.name),
                children: baes.map((b) {
                  final st = _activeStatusFor(b);
                  final info = StatusErrorVisuals.infoFor(st?.erreur);
                  return ListTile(
                    leading: Icon(info.icon, color: _colorForCode(st?.erreur)),
                    title: Text(b.name),
                    subtitle: Text(info.name),
                  );
                }).toList(),
              );
            }).toList(),
          );
        }).toList(),
      ),
    );
  }

  // UI: Tuile "Erreurs"
  Widget _buildErreursTile() {
    final site = _siteFull;
    if (site == null) return const SizedBox.shrink();

    if (!_showConnection && !_showBattery) {
      return Card(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: const ListTile(
          title: Text('Erreurs'),
          subtitle: Text("Aucun type d'erreur sélectionné."),
        ),
      );
    }

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ExpansionTile(
        initiallyExpanded: true,
        title: const Text('Erreurs'),
        children: site.batiments.map((bat) {
          final etagesWithErr = bat.etages.where((e) => e.baes.any((b) => _collectErrorLines(b).isNotEmpty));
          if (etagesWithErr.isEmpty) return const SizedBox.shrink();
          return ExpansionTile(
            title: Text(bat.name),
            children: etagesWithErr.map((etg) {
              final baesWithErr = etg.baes.where((b) => _collectErrorLines(b).isNotEmpty).toList();
              if (baesWithErr.isEmpty) return const SizedBox.shrink();
              return ExpansionTile(
                title: Text(etg.name),
                children: baesWithErr.map((b) {
                  final lines = _collectErrorLines(b);
                  return ListTile(
                    title: Text(b.name),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for (final st in lines)
                          _StatusRow(
                            status: st,
                            onIgnore: st.erreur == 6 ? null : () => _ignore(b, st.erreur),
                            onAck: st.erreur == 6 ? null : () => _ack(b, st.erreur),
                          ),
                      ],
                    ),
                  );
                }).toList(),
              );
            }).toList(),
          );
        }).toList(),
      ),
    );
  }

  // UI: Tuile "Non placé"
  Widget _buildNonPlaceTile() {
    final site = _siteFull;
    if (site == null) return const SizedBox.shrink();

    final nonPlaces = <Baes>[];
    for (final bat in site.batiments) {
      for (final etg in bat.etages) {
        for (final b in etg.baes) {
          if (b.etageId == null && _baesPassesFilters(b)) {
            nonPlaces.add(b);
          }
        }
      }
    }
    if (nonPlaces.isEmpty) return const SizedBox.shrink();

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ExpansionTile(
        initiallyExpanded: true,
        title: const Text('Non placé'),
        children: nonPlaces.map((b) {
          final st = _activeStatusFor(b);
          final info = StatusErrorVisuals.infoFor(st?.erreur);
          return ListTile(
            leading: Icon(info.icon, color: _colorForCode(st?.erreur)),
            title: Text(b.name),
            trailing: IconButton(
              icon: const Icon(Icons.map),
              tooltip: 'Aller à la gestion carte',
              onPressed: _gotoGestionCarte,
            ),
          );
        }).toList(),
      ),
    );
  }

  Color _colorForCode(int? code) {
    switch (code) {
      case 0:
        return Colors.orange; // connexion
      case 4:
        return Colors.red; // batterie
      case 6:
        return Colors.green; // OK
      default:
        return Colors.grey; // inconnu
    }
  }

  Future<void> _openManageSitesDialog() async {
    showDialog(
      context: context,
      builder: (ctx) => _ManageSitesDialog(
        sites: _sites,
        onCreate: (name) async {
          try {
            final created = await _sitesApi.create(name);
            setState(() {
              _sites = [..._sites, created];
              _selectedSite ??= created;
            });
            if (mounted) Navigator.pop(ctx);
          } catch (e) {
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Création échouée: $e')));
          }
        },
        onRename: (siteId, newName) async {
          try {
            final updated = await _sitesApi.update(siteId, name: newName);
            setState(() {
              _sites = _sites.map((s) => s.id == siteId ? updated : s).toList(growable: false);
              if (_selectedSite?.id == siteId) {
                _selectedSite = updated;
              }
            });
          } catch (e) {
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Renommage échoué: $e')));
          }
        },
        onDelete: (siteId) async {
          try {
            await _sitesApi.deleteSite(siteId);
            setState(() {
              _sites = _sites.where((s) => s.id != siteId).toList();
              if (_selectedSite?.id == siteId) {
                _selectedSite = _sites.isNotEmpty ? _sites.first : null;
                _siteFull = null;
              }
            });
            if (mounted) Navigator.pop(ctx);
          } catch (e) {
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Suppression échouée: $e')));
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Drawer(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildHeader(),
                          const SizedBox(height: 8),
                          const Text('Erreur: ', style: TextStyle(fontWeight: FontWeight.bold)),
                          Text('$_error'),
                          const SizedBox(height: 8),
                          ElevatedButton(
                            onPressed: _initData,
                            child: const Text('Réessayer'),
                          )
                        ],
                      ),
                    ),
                  )
                : SingleChildScrollView(
                    child: Column(
                      children: [
                        _buildHeader(),
                        _buildFilters(),
                        const SizedBox(height: 8),
                        if (_siteFull != null) ...[
                          _buildListeTile(),
                          _buildErreursTile(),
                          _buildNonPlaceTile(),
                        ] else
                          const Padding(
                            padding: EdgeInsets.all(16.0),
                            child: Text('Aucun site sélectionné ou données indisponibles.'),
                          ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
      ),
    );
  }
}

class _StatusRow extends StatelessWidget {
  final BaeStatus status;
  final VoidCallback? onIgnore;
  final VoidCallback? onAck;
  const _StatusRow({required this.status, this.onIgnore, this.onAck});

  @override
  Widget build(BuildContext context) {
    final info = StatusErrorVisuals.infoFor(status.erreur);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Icon(info.icon, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(info.name)),
          if (onIgnore != null)
            TextButton(onPressed: onIgnore, child: const Text('Ignorer')),
          if (onAck != null)
            TextButton(onPressed: onAck, child: const Text('Acquitter')),
        ],
      ),
    );
  }
}

class _ManageSitesDialog extends StatefulWidget {
  final List<SiteLite> sites;
  final Future<void> Function(String name) onCreate;
  final Future<void> Function(int siteId, String newName) onRename;
  final Future<void> Function(int siteId) onDelete;
  const _ManageSitesDialog({
    required this.sites,
    required this.onCreate,
    required this.onRename,
    required this.onDelete,
  });

  @override
  State<_ManageSitesDialog> createState() => _ManageSitesDialogState();
}

class _ManageSitesDialogState extends State<_ManageSitesDialog> {
  final _createCtrl = TextEditingController();
  final Map<int, TextEditingController> _renameCtrls = {};

  @override
  void dispose() {
    _createCtrl.dispose();
    for (final c in _renameCtrls.values) {
      c.dispose();
    }
    super.dispose();
  }

  TextEditingController _ctrlFor(int siteId, String initial) {
    return _renameCtrls.putIfAbsent(siteId, () => TextEditingController(text: initial));
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Gestion des sites'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Créer
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _createCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Nom du site à créer',
                  ),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () {
                  final name = _createCtrl.text.trim();
                  if (name.isEmpty) return;
                  widget.onCreate(name);
                },
                child: const Text('Créer'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Liste des sites
          SizedBox(
            width: 380,
            height: 260,
            child: widget.sites.isEmpty
                ? const Center(child: Text('Aucun site'))
                : ListView.builder(
                    itemCount: widget.sites.length,
                    itemBuilder: (ctx, i) {
                      final s = widget.sites[i];
                      final ctrl = _ctrlFor(s.id, s.name);
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: ctrl,
                                decoration: const InputDecoration(
                                  labelText: 'Nom du site',
                                  isDense: true,
                                ),
                              ),
                            ),
                            IconButton(
                              tooltip: 'Renommer',
                              icon: const Icon(Icons.save),
                              onPressed: () {
                                final newName = ctrl.text.trim();
                                if (newName.isEmpty || newName == s.name) return;
                                widget.onRename(s.id, newName);
                              },
                            ),
                            IconButton(
                              tooltip: 'Supprimer',
                              icon: const Icon(Icons.delete),
                              onPressed: () => widget.onDelete(s.id),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Fermer'),
        ),
      ],
    );
  }
}
```

---

### Points d’intégration à compléter
- _loadSiteFull(int siteId): connectez votre endpoint qui renvoie la hiérarchie complète d’un Site (Site -> Batiments -> Etages -> Baes, idéalement avec latest_status). Exemple:
  - GET /sites/{id}/full => Site
  - Créez une classe SitesDetailsApi avec Future<Site> getFull(int siteId) puis:
    - final site = await SitesDetailsApi(SessionManager.instance.client).getFull(siteId);
    - setState(() => _siteFull = site);
- _isAdminLike: remplacez la valeur par défaut par votre vérification réelle des rôles (Provider utilisateur ou API me()). Si vous utilisez le modèle User (lib\models\dto\user.dart) avec roles: ["admin", "superadmin", ...], vérifiez l’inclusion de ces valeurs.

---

### Détails sur les filtres et les tuiles
- Liste et Non placé filtrent les BAES affichés selon les cases cochées.
- Erreurs n’affiche rien quand aucune case n’est cochée (car on ne considère pas OK/Inconnu comme des “erreurs”).
- Si au moins une case est cochée, chaque BAES listé en “Erreurs” affiche jusqu’à trois lignes: Connexion (0), Batterie (4), OK (6). Les boutons “Ignorer/Acquitter” apparaissent uniquement sur les lignes non-OK.

---

### Tests à réaliser
- Deux cases cochées: toutes les BAES visibles en “Liste” et “Non placé”; “Erreurs” liste BAES ayant 0/4 quelque part, avec ligne OK ajoutée si disponible.
- Une seule case cochée: “Liste” et “Non placé” n’affichent que BAES qui sont actuellement dans ce type; “Erreurs” n’affiche que ce type + OK.
- Aucune case: “Liste” et “Non placé” ne montrent que OK et inconnus; “Erreurs” affiche le message explicite.
- Popup “Gérer les sites”: création, renommage et suppression fonctionnent; le Dropdown se met à jour.

---

### Conseils complémentaires
- Si vous avez un poller global (LatestStatusPoller), vous pouvez écouter son flux et rafraîchir _latestByBaes au lieu d’appeler StatusApi.latest() dans le drawer.
- Vous pouvez ajouter des compteurs dans le titre des tuiles (ex. nombre d’erreurs connexion/batterie).
- Si vous devez exclure les statuts isIgnored de l’affichage “Erreurs”, filtrez _collectErrorLines pour ignorer status.isIgnored.

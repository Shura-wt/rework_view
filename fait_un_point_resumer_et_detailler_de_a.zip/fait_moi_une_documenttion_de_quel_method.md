
# Documentation: ErrorProvider

## Vue d'ensemble
`ErrorProvider` est une classe qui gère la récupération, le stockage et la mise à jour des erreurs depuis l'API. Elle utilise le pattern Provider pour notifier automatiquement les widgets lorsque de nouvelles erreurs sont disponibles.

## Fonctionnalités principales
- Récupération automatique des erreurs toutes les 5 secondes
- Mise à jour automatique de l'interface utilisateur lorsque de nouvelles erreurs sont détectées
- Gestion des erreurs pour des BAES spécifiques
- Acquittement des erreurs (marquer comme résolu/ignoré)

## Méthodes disponibles

### Propriétés
- `errors` : Liste de toutes les erreurs actuellement chargées
- `isLoading` : Indique si une opération de chargement est en cours

### Constructeur
```dart
ErrorProvider()
```
Initialise le provider et démarre la récupération périodique des erreurs. Dès l'instanciation, le provider:
1. Effectue un premier chargement de toutes les erreurs
2. Configure un timer pour vérifier les nouvelles erreurs toutes les 5 secondes

### Méthodes de récupération des erreurs

#### `fetchErrors()`
```dart
Future<void> fetchErrors()
```
Récupère toutes les erreurs depuis l'API et remplace la liste actuelle. Utilisez cette méthode pour forcer un rechargement complet des erreurs.

#### `fetchNewErrors()`
```dart
Future<void> fetchNewErrors()
```
Récupère uniquement les nouvelles erreurs (celles avec un ID supérieur au dernier ID connu) et les ajoute à la liste existante. Cette méthode est appelée automatiquement toutes les 5 secondes.

#### `getLatestError()`
```dart
Future<HistoriqueErreur?> getLatestError()
```
Récupère uniquement la dernière erreur depuis l'API. Utile pour afficher l'erreur la plus récente sans charger toute la liste.

#### `getErrorsForBaes(int baesId)`
```dart
Future<List<HistoriqueErreur>> getErrorsForBaes(int baesId)
```
Récupère toutes les erreurs associées à un BAES spécifique. Utilisez cette méthode pour afficher les erreurs d'un seul BAES.

### Gestion des erreurs

#### `acknowledgeError(int errorId, bool isSolved, bool isIgnored)`
```dart
Future<bool> acknowledgeError(int errorId, bool isSolved, bool isIgnored)
```
Marque une erreur comme résolue et/ou ignorée. Retourne `true` si l'opération a réussi, `false` sinon.

## Comment utiliser ErrorProvider pour afficher les erreurs en temps réel

### 1. Accéder au provider
```dart
final errorProvider = Provider.of<ErrorProvider>(context);
```

### 2. Afficher la liste des erreurs
```dart
Consumer<ErrorProvider>(
  builder: (context, errorProvider, child) {
    if (errorProvider.isLoading) {
      return const CircularProgressIndicator();
    }
    
    return ListView.builder(
      itemCount: errorProvider.errors.length,
      itemBuilder: (context, index) {
        final error = errorProvider.errors[index];
        return ListTile(
          title: Text('Erreur: ${error.typeErreur}'),
          subtitle: Text('BAES ID: ${error.baesId}'),
          trailing: Text(error.isSolved ? 'Résolu' : 'Non résolu'),
        );
      },
    );
  },
)
```

### 3. Afficher uniquement les nouvelles erreurs
Le provider met automatiquement à jour la liste des erreurs toutes les 5 secondes. Pour afficher uniquement les nouvelles erreurs, vous pouvez:

```dart
StreamBuilder<void>(
  stream: Stream.periodic(const Duration(seconds: 1)),
  builder: (context, snapshot) {
    final errorProvider = Provider.of<ErrorProvider>(context);
    final recentErrors = errorProvider.errors
        .where((error) => error.timestamp.isAfter(DateTime.now().subtract(const Duration(minutes: 5))))
        .toList();
        
    return ListView.builder(
      itemCount: recentErrors.length,
      itemBuilder: (context, index) {
        final error = recentErrors[index];
        return ErrorCard(error: error);
      },
    );
  },
)
```

### 4. Acquitter une erreur
```dart
ElevatedButton(
  onPressed: () async {
    final success = await errorProvider.acknowledgeError(
      error.id,
      true,  // marquer comme résolu
      false, // ne pas ignorer
    );
    
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Erreur acquittée avec succès')),
      );
    }
  },
  child: const Text('Marquer comme résolu'),
)
```

## Exemple complet d'intégration

```dart
class ErrorsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Erreurs')),
      body: Consumer<ErrorProvider>(
        builder: (context, errorProvider, child) {
          if (errorProvider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }
          
          if (errorProvider.errors.isEmpty) {
            return const Center(child: Text('Aucune erreur à afficher'));
          }
          
          return RefreshIndicator(
            onRefresh: () => errorProvider.fetchErrors(),
            child: ListView.builder(
              itemCount: errorProvider.errors.length,
              itemBuilder: (context, index) {
                final error = errorProvider.errors[index];
                return ErrorListItem(error: error);
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Provider.of<ErrorProvider>(context, listen: false).fetchErrors();
        },
        child: const Icon(Icons.refresh),
      ),
    );
  }
}
```

## Notes importantes
- Le provider est automatiquement initialisé au démarrage de l'application via `MultiProvider` dans `main.dart`
- Les erreurs sont triées par ID décroissant (les plus récentes en premier)
- Le timer est automatiquement annulé lorsque le provider est disposé
- Pour afficher les erreurs en temps réel, utilisez toujours `Consumer<ErrorProvider>` ou `context.watch<ErrorProvider>()` pour être notifié des changements
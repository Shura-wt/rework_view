### Plan d’implémentation du LeftDrawer (suite de la réflexion)

Ci-dessous, je vous propose une implémentation complète et modulaire du LeftDrawer conforme aux règles que vous avez données. Elle s’appuie sur les APIs et modèles déjà présents dans votre code (SitesApi, StatusApi, modèles Site/Batiment/Etage/Baes/BaeStatus, StatusErrorVisuals) et respecte la logique des filtres et des tuiles.

---

### Règles fonctionnelles rappelées

- Haut du drawer: un Dropdown affichant la liste des sites disponibles pour l’utilisateur connecté. Si rôle admin/superadmin, afficher un bouton pour ouvrir un popup permettant d’ajouter/supprimer un site.
- En dessous: 2 checkbox de filtre
  - Afficher “status de connexion” (erreur code 0)
  - Afficher “status de batterie” (erreur code 4)
  - Si les deux sont décochées: n’afficher que les status OK (6) et les inconnus
- Trois tuiles en dessous:
  1) “Liste”: site -> batiment -> étage -> BAES
  2) “Erreurs”: mêmes niveaux, mais ne montrer que BAES qui ont des erreurs du type activé. Sur la dernière ligne (par BAES), afficher au maximum 1 ligne par type (OK/connexion/batterie), donc max 3 lignes, avec boutons Ignorer/Acquitter si ce n’est pas OK.
  3) “Non placé”: liste des BAES sans étage (etageId == null), sur chaque ligne un icône qui navigue vers la page Gestion Carte.
- Les filtres s’appliquent sur les tuiles.

---

### Hypothèses/Notes d’intégration

- SitesApi.list() retournera la liste des sites accessibles à l’utilisateur (souvent filtrée côté backend via le token). Sinon, remplacez par une méthode dédiée si vous en avez une.
- Pour obtenir la hiérarchie complète Site->Batiments->Etages->Baes, si vous avez un endpoint “site detail” différent de SitesApi.getById (qui renvoie SiteLite), créez un SitesDetailsApi.getFull(siteId) => Site. Ci-dessous, je mets un fetch “_loadSiteFull” à adapter.
- Les statuts: je privilégie Baes.latestStatus si présent dans vos objets; en fallback, j’utilise StatusApi.latest() et je re-map par baesId.
- Rôles admin/superadmin: si vous avez un User courant dans un Provider, utilisez-le; sinon, vous pouvez récupérer ses rôles via une API dédiée. Ci-dessous, je mets un booléen “_isAdminLike” que vous brancherez facilement.

---

### Code proposé (à coller dans lib\components\drawer.dart)

Remplacez le contenu du fichier actuel par le code suivant. Comme le fichier est “part of ‘../main.dart’”, il a accès à vos imports globaux (APIs, modèles). Vous pourrez ajuster les TODO indiqués.

```dart
part of '../main.dart';

class LeftDrawer extends StatefulWidget {
  const LeftDrawer({super.key});

  @override
  State<LeftDrawer> createState() => _LeftDrawerState();
}

class _LeftDrawerState extends State<LeftDrawer> {
  final _sitesApi = SitesApi(SessionManager.instance.client);
  final _statusApi = StatusApi(SessionManager.instance.client);

  // État local
  List<SiteLite> _sites = const [];
  SiteLite? _selectedSite;

  // Site complet pour construire les tuiles
  Site? _siteFull;

  // Statuts latest indexés par baesId
  Map<int, BaeStatus> _latestByBaes = const {};

  bool _loading = true;
  Object? _error;

  // Filtres
  bool _showConnection = true; // erreur 0
  bool _showBattery = true;    // erreur 4

  // Droits (à brancher selon votre logique réelle)
  bool get _isAdminLike {
    // TODO: Branchez votre user courant ici si disponible (Provider, etc.)
    // Par défaut, je renvoie true pour démonstration.
    // Ex: final user = context.watch<UserProvider>().currentUser;
    // return user.roles.contains('admin') || user.roles.contains('superadmin');
    return true;
  }

  @override
  void initState() {
    super.initState();
    _initData();
  }

  Future<void> _initData() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      // 1) Charger sites accessibles
      final sites = await _sitesApi.list();
      SiteLite? selected = _selectedSite;
      if (sites.isNotEmpty) {
        selected ??= sites.first;
      }
      _sites = sites;
      _selectedSite = selected;

      // 2) Charger données complètes du site sélectionné
      if (_selectedSite != null) {
        await _loadSiteFull(_selectedSite!.id);
      }

      // 3) Charger les derniers statuts (fallback au cas où latestStatus est null)
      final latest = await _statusApi.latest();
      _latestByBaes = {
        for (final st in latest)
          if (st.baesId != null) st.baesId!: st,
      };

      setState(() {
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e;
        _loading = false;
      });
    }
  }

  Future<void> _loadSiteFull(int siteId) async {
    // TODO: Remplacez ceci par votre endpoint réel renvoyant un Site complet
    // Exemple: final site = await SitesDetailsApi(SessionManager.instance.client).getFull(siteId);
    // Ici, on tente une reconstruction minimale si vous avez déjà une structure ailleurs.
    // Vous pouvez aussi stocker le site complet dans un Provider global lorsque vous entrez sur la page.
    throw UnimplementedError('Brancher un fetch Site complet (Site with batiments/etages/baes)');
  }

  void _onSiteChanged(SiteLite? site) async {
    if (site == null) return;
    setState(() {
      _selectedSite = site;
      _siteFull = null;
      _loading = true;
      _error = null;
    });
    try {
      await _loadSiteFull(site.id);
      setState(() {
        _loading = false;
      });
    } catch (e) {
      setState(() { _error = e; _loading = false; });
    }
  }

  // Helpers statut/filtre
  bool _isOkOrUnknown(int? code) {
    // OK = 6; inconnu = non mappé -> StatusErrorVisuals.infoFor(code) == unknown
    if (code == 6) return true;
    final info = StatusErrorVisuals.infoFor(code);
    return identical(info, StatusErrorVisuals.unknown);
  }

  bool _passFilters(BaeStatus? st) {
    if (st == null) return _isOkOrUnknown(null);
    final code = st.erreur;
    final isConn = (code == 0);
    final isBatt = (code == 4);
    // Si aucune case n’est cochée => seulement OK (6) + inconnus
    if (!_showConnection && !_showBattery) {
      return _isOkOrUnknown(code);
    }
    // Sinon, on inclut les types cochés + OK ?
    // Vous avez demandé d’appliquer les filtres; classiquement pour l’affichage Erreurs on n’inclut pas OK
    if (_showConnection && isConn) return true;
    if (_showBattery && isBatt) return true;
    return false;
  }

  // Récupère le “statut actif” d’un BAES: latestStatus s’il existe sinon fallback latestByBaes
  BaeStatus? _activeStatusFor(Baes b) {
    return b.latestStatus ?? _latestByBaes[b.id];
  }

  // Pour la tuile Erreurs: restituer jusqu’à 3 lignes par BAES (OK/Connexion/Batterie)
  List<BaeStatus> _collectStatusLines(Baes b) {
    final lines = <BaeStatus>[];
    final latest = _activeStatusFor(b);

    // On tente de dériver 3 “types” maximum, en priorité depuis l’historique s’il existe
    // 1) Connexion (0)
    final conn = b.statuses.firstWhere(
      (s) => s.erreur == 0,
      orElse: () => latest?.erreur == 0 ? latest! : null as BaeStatus,
    );
    if (conn != null) lines.add(conn);

    // 2) Batterie (4)
    final batt = b.statuses.firstWhere(
      (s) => s.erreur == 4,
      orElse: () => latest?.erreur == 4 ? latest! : null as BaeStatus,
    );
    if (batt != null) lines.add(batt);

    // 3) OK (6) — utile pour visualiser un retour à la normale
    final ok = b.statuses.firstWhere(
      (s) => s.erreur == 6,
      orElse: () => latest?.erreur == 6 ? latest! : null as BaeStatus,
    );
    if (ok != null) lines.add(ok);

    // Appliquer le filtre
    final filtered = lines.where(_passFilters).toList(growable: false);

    // Si aucun ne passe (p.ex. aucun coché mais on veut montrer OK/inconnus):
    if (filtered.isEmpty && !_showConnection && !_showBattery) {
      if (latest == null || _isOkOrUnknown(latest.erreur)) {
        if (latest != null) return [latest];
      }
    }
    return filtered.take(3).toList(growable: false);
  }

  Future<void> _ignore(Baes b, int erreur) async {
    try {
      final updated = await _statusApi.updateBaesType(b.id, erreur, isIgnored: true);
      // Option: mettez à jour le cache local (latestByBaes, b.latestStatus...) si souhaité
      setState(() {
        _latestByBaes = Map<int, BaeStatus>.from(_latestByBaes)..[b.id] = updated;
      });
    } catch (e) {
      if (mounted) ApiErrorHandler.showSnackBar(context, e, action: 'ignorer');
    }
  }

  Future<void> _ack(Baes b, int erreur) async {
    try {
      final updated = await _statusApi.updateBaesType(b.id, erreur, isSolved: true);
      setState(() {
        _latestByBaes = Map<int, BaeStatus>.from(_latestByBaes)..[b.id] = updated;
      });
    } catch (e) {
      if (mounted) ApiErrorHandler.showSnackBar(context, e, action: 'acquitter');
    }
  }

  void _gotoGestionCarte() {
    Navigator.pop(context); // ferme le drawer
    Navigator.pushNamed(context, '/admin/carte');
  }

  // UI — Header avec Dropdown sites + bouton admin gestion sites
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          Expanded(
            child: DropdownButton<SiteLite>(
              isExpanded: true,
              value: _selectedSite,
              items: _sites.map((s) => DropdownMenuItem(
                value: s,
                child: Text(s.name),
              )).toList(),
              onChanged: _onSiteChanged,
            ),
          ),
          if (_isAdminLike)
            IconButton(
              icon: const Icon(Icons.settings),
              tooltip: 'Gérer les sites',
              onPressed: _openManageSitesDialog,
            ),
        ],
      ),
    );
  }

  Future<void> _openManageSitesDialog() async {
    showDialog(
      context: context,
      builder: (ctx) => _ManageSitesDialog(
        sites: _sites,
        onCreate: (name) async {
          try {
            final created = await _sitesApi.create(name);
            setState(() {
              _sites = [..._sites, created];
              _selectedSite ??= created;
            });
            if (mounted) Navigator.pop(ctx);
          } catch (e) {
            ApiErrorHandler.showSnackBar(context, e, action: 'create site');
          }
        },
        onDelete: (siteId) async {
          try {
            await _sitesApi.deleteSite(siteId);
            setState(() {
              _sites = _sites.where((s) => s.id != siteId).toList();
              if (_selectedSite?.id == siteId) {
                _selectedSite = _sites.isNotEmpty ? _sites.first : null;
                _siteFull = null;
              }
            });
            if (mounted) Navigator.pop(ctx);
          } catch (e) {
            ApiErrorHandler.showSnackBar(context, e, action: 'delete site');
          }
        },
      ),
    );
  }

  Widget _buildFilters() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Column(
        children: [
          CheckboxListTile(
            value: _showConnection,
            onChanged: (v) => setState(() => _showConnection = v ?? false),
            title: const Text('Afficher status de connexion (erreur 0)'),
          ),
          CheckboxListTile(
            value: _showBattery,
            onChanged: (v) => setState(() => _showBattery = v ?? false),
            title: const Text('Afficher status de batterie (erreur 4)'),
          ),
          if (!_showConnection && !_showBattery)
            const Padding(
              padding: EdgeInsets.only(left: 16, bottom: 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Filtre actif: seulement OK (6) et inconnus'),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildListeTile() {
    final site = _siteFull;
    if (site == null) return const SizedBox.shrink();

    return Card(
      margin: const EdgeInsets.all(12),
      child: ExpansionTile(
        initiallyExpanded: true,
        title: const Text('Liste'),
        children: site.batiments.map((bat) {
          return ExpansionTile(
            title: Text(bat.name),
            children: bat.etages.map((etg) {
              return ExpansionTile(
                title: Text(etg.name),
                children: etg.baes.map((b) {
                  final st = _activeStatusFor(b);
                  final info = StatusErrorVisuals.infoFor(st?.erreur);
                  return ListTile(
                    leading: Icon(info.icon, color: _colorForCode(st?.erreur)),
                    title: Text(b.name),
                    subtitle: Text(info.name),
                  );
                }).toList(),
              );
            }).toList(),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildErreursTile() {
    final site = _siteFull;
    if (site == null) return const SizedBox.shrink();

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ExpansionTile(
        initiallyExpanded: true,
        title: const Text('Erreurs'),
        children: site.batiments.map((bat) {
          final etagesWithErr = bat.etages.where((e) => e.baes.any((b) => _collectStatusLines(b).isNotEmpty));
          if (etagesWithErr.isEmpty) return const SizedBox.shrink();
          return ExpansionTile(
            title: Text(bat.name),
            children: etagesWithErr.map((etg) {
              final baesWithErr = etg.baes.where((b) => _collectStatusLines(b).isNotEmpty).toList();
              if (baesWithErr.isEmpty) return const SizedBox.shrink();
              return ExpansionTile(
                title: Text(etg.name),
                children: baesWithErr.map((b) {
                  final lines = _collectStatusLines(b);
                  if (lines.isEmpty) return const SizedBox.shrink();
                  return ListTile(
                    title: Text(b.name),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        for (final st in lines)
                          _StatusRow(
                            status: st,
                            onIgnore: st.erreur == 6 ? null : () => _ignore(b, st.erreur),
                            onAck: st.erreur == 6 ? null : () => _ack(b, st.erreur),
                          ),
                      ],
                    ),
                  );
                }).toList(),
              );
            }).toList(),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildNonPlaceTile() {
    final site = _siteFull;
    if (site == null) return const SizedBox.shrink();

    final nonPlaces = <Baes>[];
    for (final bat in site.batiments) {
      for (final etg in bat.etages) {
        for (final b in etg.baes) {
          if (b.etageId == null) nonPlaces.add(b);
        }
      }
    }

    if (nonPlaces.isEmpty) return const SizedBox.shrink();

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ExpansionTile(
        initiallyExpanded: true,
        title: const Text('Non placé'),
        children: nonPlaces.map((b) {
          final st = _activeStatusFor(b);
          final info = StatusErrorVisuals.infoFor(st?.erreur);
          return ListTile(
            leading: Icon(info.icon, color: _colorForCode(st?.erreur)),
            title: Text(b.name),
            trailing: IconButton(
              icon: const Icon(Icons.map),
              tooltip: 'Aller à la gestion carte',
              onPressed: _gotoGestionCarte,
            ),
          );
        }).toList(),
      ),
    );
  }

  Color _colorForCode(int? code) {
    switch (code) {
      case 0: return Colors.orange;  // connexion
      case 4: return Colors.red;     // batterie
      case 6: return Colors.green;   // OK
      default: return Colors.grey;   // inconnu
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Drawer(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? SingleChildScrollView(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildHeader(),
                          const SizedBox(height: 8),
                          Text('Erreur: \n\n\t\t\t\t\t\t\t\t\t\t', style: const TextStyle(fontWeight: FontWeight.bold)),
                          Text('$_error'),
                          const SizedBox(height: 8),
                          ElevatedButton(
                            onPressed: _initData,
                            child: const Text('Réessayer'),
                          )
                        ],
                      ),
                    ),
                  )
                : SingleChildScrollView(
                    child: Column(
                      children: [
                        _buildHeader(),
                        _buildFilters(),
                        const SizedBox(height: 8),
                        if (_siteFull != null) ...[
                          _buildListeTile(),
                          _buildErreursTile(),
                          _buildNonPlaceTile(),
                        ] else
                          const Padding(
                            padding: EdgeInsets.all(16.0),
                            child: Text('Aucun site sélectionné ou données indisponibles.'),
                          ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
      ),
    );
  }
}

class _StatusRow extends StatelessWidget {
  final BaeStatus status;
  final VoidCallback? onIgnore;
  final VoidCallback? onAck;
  const _StatusRow({required this.status, this.onIgnore, this.onAck});

  @override
  Widget build(BuildContext context) {
    final info = StatusErrorVisuals.infoFor(status.erreur);
    return Row(
      children: [
        Icon(info.icon, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(info.name)),
        if (onIgnore != null)
          TextButton(onPressed: onIgnore, child: const Text('Ignorer')),
        if (onAck != null)
          TextButton(onPressed: onAck, child: const Text('Acquitter')),
      ],
    );
  }
}

class _ManageSitesDialog extends StatefulWidget {
  final List<SiteLite> sites;
  final Future<void> Function(String name) onCreate;
  final Future<void> Function(int siteId) onDelete;
  const _ManageSitesDialog({
    required this.sites,
    required this.onCreate,
    required this.onDelete,
  });

  @override
  State<_ManageSitesDialog> createState() => _ManageSitesDialogState();
}

class _ManageSitesDialogState extends State<_ManageSitesDialog> {
  final _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Gestion des sites'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _controller,
            decoration: const InputDecoration(
              labelText: 'Nom du site à créer',
            ),
          ),
          const SizedBox(height: 12),
          if (widget.sites.isEmpty)
            const Text('Aucun site'),
          if (widget.sites.isNotEmpty)
            SizedBox(
              width: 300,
              height: 200,
              child: ListView.builder(
                itemCount: widget.sites.length,
                itemBuilder: (ctx, i) {
                  final s = widget.sites[i];
                  return ListTile(
                    title: Text(s.name),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete),
                      tooltip: 'Supprimer',
                      onPressed: () => widget.onDelete(s.id),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Fermer'),
        ),
        ElevatedButton(
          onPressed: () {
            final name = _controller.text.trim();
            if (name.isEmpty) return;
            widget.onCreate(name);
          },
          child: const Text('Créer'),
        ),
      ],
    );
  }
}
```

---

### Points à ajuster selon votre backend

- Méthode `_loadSiteFull`: branchez-la sur votre endpoint qui retourne un Site complet avec batiments -> étages -> baes (et idéalement latestStatus). Exemple:
  - GET /sites/{id}/full => Site
  - Ou, si vous avez déjà ces données ailleurs (cache/Provider), affectez simplement `_siteFull`.
- Récupération de l’utilisateur courant et des rôles: si vous avez un UserApi.me(), utilisez-le pour calculer `_isAdminLike`. Remplacez le `return true;` par la logique réelle.
- Si StatusApi.latest() est déjà lancé via votre poller global (LatestStatusPoller), vous pouvez injecter ces données via un Provider/Stream plutôt que d’appeler latest() dans le drawer. Dans ce cas, supprimez la partie “latest()” et l’indexation `_latestByBaes`.

---

### Détails sur la logique de filtre

- Si au moins une case est cochée:
  - La tuile “Erreurs” montre uniquement les statuts des types cochés (0 et/ou 4) — au plus 1 ligne par type et par BAES.
- Si aucune case n’est cochée:
  - “Erreurs” n’affiche que OK (6) et/ou Inconnus pour un BAES; dans l’exemple ci-dessus, on ne monte la ligne que si le latest correspond à OK/inconnu. Vous pouvez choisir d’afficher la ligne OK même en l’absence d’erreurs.
- Les tuiles “Liste” et “Non placé” ne filtrent pas leur arbre structurel, mais l’icône et le label du BAES reflètent son statut actif.

---

### Améliorations possibles

- Afficher des compteurs (ex: nombre d’erreurs connexion/batterie dans le titre de la tuile Erreurs).
- Ajouter un filtre “Ignorés” (montrer/cacher) si vous souhaitez ne pas lister les erreurs isIgnored.
- Pour “Acquitter”: si votre backend nécessite de renseigner l’utilisateur qui acquitte, utilisez `updateStatus` (par statusId) avec `acknowledged_by_user_id` et `acknowledged_at` plutôt que `updateBaesType`. Ici, j’ai utilisé `updateBaesType` pour coller à votre besoin “par type pour un BAES”.

---

### Conclusion

Le code ci-dessus concrétise votre demande: Dropdown des sites, bouton de gestion (admin/superadmin), deux filtres d’affichage, et trois tuiles (Liste, Erreurs, Non placé) avec actions Ignorer/Acquitter, en vous laissant un seul point d’intégration à compléter: le chargement du site complet. Dites-moi si vous souhaitez que je l’intègre à partir d’un endpoint précis, ou si je dois adapter la logique de filtre (par ex. inclure toujours “OK” dans la tuile Erreurs quand une case est cochée).
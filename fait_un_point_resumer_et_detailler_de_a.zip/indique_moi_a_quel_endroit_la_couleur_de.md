### Gestion de la couleur de l'icône lightbulb sur la carte des étages

La couleur de l'icône `Icons.lightbulb` sur la carte des étages est gérée à deux endroits principaux dans le code :

#### 1. Dans le fichier view.dart

La couleur est définie aux lignes 568-574 et 1115-1121 avec la même logique :

```dart
color: (statusConnection || batteryError)
    ? Colors.red
    : evryErrorIgnored
        ? Colors.orange
        : Colors.green,
```

La couleur est choisie selon ces critères :
- **Rouge** : Si le BAES a des erreurs de connexion ou de batterie actives (non résolues et non ignorées)
- **Orange** : Si toutes les erreurs sont ignorées
- **Vert** : Si le BAES n'a pas d'erreurs ou si toutes les erreurs sont résolues

Les erreurs sont détectées par type :
- Erreurs de connexion : type 'connection' ou 'erreur_connexion'
- Erreurs de batterie : type 'battery' ou 'erreur_batterie'

#### 2. Dans le fichier gestion_carte.dart

La couleur est définie aux lignes 1382-1398 :

```dart
Color markerColor;
if (isSelected) {
  // Si le BAES est sélectionné, il est toujours orange
  markerColor = Colors.orange;
} else if (hasConnectionError || hasBatteryError) {
  // Si le BAES a des erreurs actives, il est rouge
  markerColor = Colors.red;
} else if (anyErrorIgnored) {
  // Si le BAES a des erreurs ignorées (mais pas d'erreurs actives), il est orange
  markerColor = Colors.orange;
} else {
  // Sinon (pas d'erreurs ou toutes résolues), il est vert
  markerColor = Colors.green;
}
```

La couleur est choisie selon ces critères :
- **Orange** : Si le BAES est sélectionné
- **Rouge** : Si le BAES a des erreurs de connexion ou de batterie actives
- **Orange** : Si le BAES a des erreurs ignorées (mais pas d'erreurs actives)
- **Vert** : Si le BAES n'a pas d'erreurs ou si toutes les erreurs sont résolues

Les erreurs sont détectées par code :
- Erreurs de connexion : code 0
- Erreurs de batterie : code 4

L'icône est ensuite affichée avec la couleur déterminée à la ligne 1410 :
```dart
color: markerColor,
```

### Résumé

La couleur de l'icône lightbulb est déterminée en fonction de l'état des erreurs du BAES :
- **Rouge** : Erreurs actives (connexion ou batterie)
- **Orange** : Erreurs ignorées ou BAES sélectionné
- **Vert** : Pas d'erreurs ou toutes les erreurs résolues
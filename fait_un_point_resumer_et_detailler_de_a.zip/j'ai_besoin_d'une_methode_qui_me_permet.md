### Objectif
Mettre en place un poller qui appelle l’API “latest status” toutes les 5 secondes, compare le dernier statut reçu au précédent, et ne rafraîchit qu’un widget ciblé quand il y a un changement, avec logs/erreurs lisibles et utilisation minimale des ressources.

- Intervalle: 5 s (configurable)
- Anti-chevauchement: pas d’appels concurrents
- Comparaison: par updated_at/timestamp/id + champs clés
- Diffusion: via ValueNotifier pour ne rebuild qu’un sous-arbre widget
- Persistance (optionnelle): stocke id/updated_at pour référence
- Erreurs: logs debug détaillés (code/message/body) via ApiErrorHandler; message utilisateur optionnel
- Fuseau horaire: déjà géré (UTC+00 -> UTC+02) par votre json_utils.asDateTime

---

### 1) Service de polling
Créez un nouveau fichier: lib/services/status_poller.dart

```dart
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../auth/session.dart';
import '../api/api.dart';
import '../models/models.dart';

class LatestStatusPoller {
  static final LatestStatusPoller instance = LatestStatusPoller._internal();
  LatestStatusPoller._internal();

  // Notifier auquel les widgets peuvent s’abonner
  final ValueNotifier<BaeStatus?> latestStatusNotifier = ValueNotifier<BaeStatus?>(null);

  // Clés de persistance (facultatif)
  static const _kLastIdKey = 'latest_status_last_id';
  static const _kLastUpdatedKey = 'latest_status_last_updated_at';

  Timer? _timer;
  bool _isRunning = false;
  bool _fetching = false;
  Duration _interval = const Duration(seconds: 5);

  BaeStatus? get lastKnown => latestStatusNotifier.value;

  Future<void> start({Duration interval = const Duration(seconds: 5)}) async {
    if (_isRunning) return;
    _interval = interval;
    await _loadLastFromPrefs();
    _isRunning = true;
    // Tick immédiat pour récupérer un état dès le démarrage
    _tick();
    _timer = Timer.periodic(_interval, (_) => _tick());
  }

  void stop() {
    _isRunning = false;
    _timer?.cancel();
    _timer = null;
  }

  Future<void> _loadLastFromPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final lastId = prefs.getInt(_kLastIdKey);
      final lastUpdated = prefs.getString(_kLastUpdatedKey);
      // Si vous souhaitez rétablir un objet complet, stockez latest en JSON.
      // Ici on ne restaure pas l’objet complet pour éviter d’afficher des données périmées.
      if (kDebugMode) {
        if (lastId != null || (lastUpdated != null && lastUpdated.isNotEmpty)) {
          debugPrint('[DEBUG_LOG] status_poller_load lastId=$lastId lastUpdated=$lastUpdated');
        }
      }
    } catch (e) {
      ApiErrorHandler.logDebug(e, context: 'status_poller_load');
    }
  }

  Future<void> _saveLastToPrefs(BaeStatus status) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_kLastIdKey, status.id ?? 0);
      await prefs.setString(_kLastUpdatedKey, status.updatedAt?.toIso8601String() ?? '');
    } catch (e) {
      ApiErrorHandler.logDebug(e, context: 'status_poller_save');
    }
  }

  Future<void> _tick() async {
    if (!_isRunning || _fetching) return;
    _fetching = true;
    try {
      final api = StatusApi(SessionManager.instance.client);
      final list = await api.latest();
      if (list.isEmpty) return;

      // Choisir le plus récent: updated_at > timestamp > id
      BaeStatus pickLatest(BaeStatus a, BaeStatus b) {
        final aUp = a.updatedAt;
        final bUp = b.updatedAt;
        if (aUp != null && bUp != null) return aUp.isAfter(bUp) ? a : b;
        final aTs = a.timestamp;
        final bTs = b.timestamp;
        if (aTs != null && bTs != null) return aTs.isAfter(bTs) ? a : b;
        final aId = a.id ?? 0;
        final bId = b.id ?? 0;
        return aId >= bId ? a : b;
      }

      final latest = list.reduce(pickLatest);
      final prev = latestStatusNotifier.value;
      final changed = _hasChanged(prev, latest);

      if (changed) {
        latestStatusNotifier.value = latest; // Notifie seulement en cas de changement
        await _saveLastToPrefs(latest);
      }
    } on Object catch (e) {
      // Log debug détaillé (status code + message + body si ApiException)
      ApiErrorHandler.logDebug(e, context: 'status_poller');
      // Pas de SnackBar ici (service sans BuildContext). L’UI peut en afficher si nécessaire.
    } finally {
      _fetching = false;
    }
  }

  bool _hasChanged(BaeStatus? prev, BaeStatus next) {
    if (prev == null) return true;

    // Compare id quand dispo
    final prevId = prev.id;
    final nextId = next.id;
    if (prevId != null && nextId != null && prevId != nextId) return true;

    // Compare updated_at
    final pUp = prev.updatedAt?.toUtc();
    final nUp = next.updatedAt?.toUtc();
    if (pUp != null || nUp != null) {
      if (pUp == null || nUp == null) return true;
      if (!pUp.isAtSameMomentAs(nUp)) return true;
    }

    // Champs métier importants
    if (prev.baesId != next.baesId) return true;
    if (prev.erreur != next.erreur) return true;
    if (prev.isSolved != next.isSolved) return true;
    if (prev.isIgnored != next.isIgnored) return true;

    return false;
  }
}
```

Notes:
- StatusApi.latest() renvoie une liste selon votre spec. Si votre backend renvoie un seul objet, adaptez pour supprimer la réduction.
- Les DateTime sont déjà transformées vers UTC+02 par json_utils.asDateTime; le poller n’a rien à faire de plus.

---

### 2) Démarrer/arrêter le poller
Démarrez-le quand l’utilisateur arrive sur la Home et arrêtez-le au besoin (par exemple au logout).

Dans lib/page/home.dart, _HomePageState:

```dart
@override
void initState() {
  super.initState();
  LatestStatusPoller.instance.start(interval: const Duration(seconds: 5));
}

@override
void dispose() {
  // Optionnel: si votre Home reste la page principale, vous pouvez ne pas stopper ici.
  LatestStatusPoller.instance.stop();
  super.dispose();
}
```

Au moment du logout (vous avez déjà la gestion d’erreur uniforme), vous pouvez également arrêter le poller:

```dart
onPressed: () async {
  try {
    LatestStatusPoller.instance.stop();
    await SessionManager.instance.logout();
  } on Object catch (e) {
    ApiErrorHandler.logDebug(e, context: 'logout');
    if (mounted) {
      ApiErrorHandler.showSnackBar(context, e, action: 'logout');
    }
  } finally {
    if (!mounted) return;
    Navigator.pushReplacementNamed(context, '/login');
  }
},
```

---

### 3) Rafraîchir un widget spécifique uniquement
Dans lib/page/view.dart, écoutez le notifier via ValueListenableBuilder pour rebuild uniquement le widget ciblé.

```dart
import 'package:flutter/material.dart';
import '../services/status_poller.dart';

class VisualisationCartePage extends StatefulWidget {
  const VisualisationCartePage({super.key});

  @override
  State<VisualisationCartePage> createState() => _VisualisationCartePageState();
}

class _VisualisationCartePageState extends State<VisualisationCartePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Page de gestion de la carte'),
            const SizedBox(height: 16),
            ValueListenableBuilder<BaeStatus?>(
              valueListenable: LatestStatusPoller.instance.latestStatusNotifier,
              builder: (context, status, _) {
                if (status == null) {
                  return const Text('Aucun statut récent');
                }
                final updated = status.updatedAt; // déjà UTC+02
                final info = 'BAES #${status.baesId} · Err=${status.erreur} · '
                    'Solved=${status.isSolved} · Ignored=${status.isIgnored}';
                return Column(
                  children: [
                    Text(info),
                    if (updated != null) Text('Dernière mise à jour: $updated'),
                    // TODO: Rafraîchissez ici votre widget précis (ex: marker sur carte)
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
```

Seule la zone à l’intérieur du ValueListenableBuilder se reconstruit quand le statut change, sans rafraîchir toute la page.

---

### 4) Variante Provider (facultatif)
Vous pouvez aussi envelopper latestStatusNotifier avec un ValueListenableProvider (package provider déjà présent) si vous préférez l’injection/consommation par Provider. Pour ce besoin, ValueNotifier + singleton reste le plus léger.

---

### 5) Gestion d’erreurs cohérente
- Le service loggue les erreurs via ApiErrorHandler.logDebug(e, context: 'status_poller').
- Si vous souhaitez prévenir l’utilisateur en cas d’erreurs répétées, vous pouvez ajouter un compteur d’échecs dans le service et exposer un autre ValueNotifier<bool> “hasError”, puis afficher une SnackBar côté UI quand nécessaire.

---

### 6) Optimisations possibles
- Utiliser GET /status/after/{updated_at} pour ne récupérer que les changements depuis le dernier updated_at connu. Mémorisez le dernier updated_at dans le service et appelez listAfter().
- Backoff exponentiel en cas d’échecs répétés (augmenter temporairement l’intervalle à 10/20/30s, puis revenir à 5s après un succès).
- Persister l’objet complet latest pour restaurer un rendu immédiat au démarrage.

---

### Récapitulatif
- Service LatestStatusPoller: Timer 5s, no overlap, compare et notifie via ValueNotifier uniquement en cas de changement.
- Intégration HomePage: start/stop (et stop au logout).
- Widget ciblé: ValueListenableBuilder pour rebuild partiel.
- Erreurs: logs détaillés, messages utilisateur si souhaité.
- Dates: déjà gérées en UTC+02 par vos parseurs, aucune étape supplémentaire nécessaire côté poller.
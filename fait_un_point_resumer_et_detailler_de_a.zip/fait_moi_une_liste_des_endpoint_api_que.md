### Objectif
Dresser la liste des endpoints API nécessaires pour implémenter le LeftDrawer tel que spécifié, en indiquant ceux déjà présents et ceux à créer, avec formats de réponse alignés avec vos modèles Flutter.

---

### Auth / Utilisateur (rôles et sites accessibles)
- [NOUVEAU] GET /me
  - But: obtenir l’utilisateur courant avec ses rôles et la liste des sites accessibles (pour le Dropdown et pour savoir si admin/superadmin).
  - Réponse (User):
    - { id: number, login: string, roles: string[], sites: SiteLite[] }
  - Note: correspond à lib/models/dto/user.dart

- [EXISTANT – optionnel] /user_site_role/* (granulaire)
  - Vous avez déjà UserSiteRoleApi pour des opérations avancées. Pour le Drawer, /me suffit généralement.

---

### Sites (liste, sélection et gestion admin)
- [EXISTANT] GET /sites/
  - Liste des sites (SiteLite[]) – déjà utilisé par SitesApi.list().

- [EXISTANT] GET /sites/{site_id}
  - Détail en SiteLite – déjà utilisé par SitesApi.getById().

- [EXISTANT] POST /sites/
  - Création d’un site (admin) – SitesApi.create().

- [EXISTANT] PUT /sites/{site_id}
  - Renommer/éditer un site (admin) – SitesApi.update().

- [EXISTANT] DELETE /sites/{site_id}
  - Suppression d’un site (admin) – SitesApi.deleteSite().

- [NOUVEAU — CRITIQUE] GET /sites/{site_id}/full
  - But: fournir la hiérarchie complète nécessaire au Drawer et aux tuiles: Site -> Batiments -> Etages -> Baes, avec latest_status pour chaque BAES (et éventuellement un sous-ensemble de statuses[] pour les types 0/4/6).
  - Réponse (Site):
    - {
      id, name, carte: {...},
      batiments: [
        { id, name, polygon_points: {...}, etages: [
          { id, name, carte: {...}, baes: [
            { id, name, position: {...}, etage_id: number|null, label: string|null,
              latest_status: { id, erreur, is_ignored, is_solved, temperature, timestamp, vibration, baes_id, updated_at, acknowledged_at, acknowledged_by_login, acknowledged_by_user_id },
              // optionnel: statuses: [ { mêmes champs que ci-dessus } ]
            }
          ]}
        ]}
      ]
    }

- [NOUVEAU — optionnel] GET /sites/my
  - But: lister uniquement les sites accessibles à l’utilisateur courant (SiteLite[]). Alternative à /me.sites ou à un filtrage serveur sur /sites/.

---

### BAES non placés (etage_id == null)
- [NOUVEAU — utile si /full ne suffit pas] GET /sites/{site_id}/baes/unassigned
  - But: récupérer rapidement les BAES sans étage pour la tuile « Non placé » sans charger toute la hiérarchie.
  - Réponse: [ { id, name, position: {...}, etage_id: null, label: string|null, latest_status: {...} } ]
  - Remarque: inutile si /sites/{id}/full retourne déjà tous les BAES (on peut filtrer côté front sur etage_id == null).

---

### Statuts (affichage, filtres, ignorer/acquitter)
- [EXISTANT] GET /status/latest
  - But: récupérer les derniers statuts (par BAES) – déjà implémenté (StatusApi.latest()). Utile en fallback si /full ne fournit pas latest_status.

- [EXISTANT] PUT /status/baes/{baes_id}/type/{erreur}
  - But: ignorer (is_ignored) ou acquitter (is_solved) un type de statut pour un BAES – déjà implémenté (StatusApi.updateBaesType()).
  - Corps: { is_ignored?: boolean, is_solved?: boolean }

- [EXISTANT – alternative ciblée] PUT /status/{status_id}/status
  - But: même action mais par status_id – déjà implémenté (StatusApi.updateStatus()).

- [EXISTANT] GET /status/baes/{baes_id}
  - But: historique d’un BAES (utile si vous voulez retrouver explicitement des lignes de type 0/4/6).

- [NOUVEAU — optionnel perf] GET /status/site/{site_id}/latest
  - But: latest restreint à un site (réduit la charge par rapport à /status/latest global).

- [NOUVEAU — optionnel analytics] GET /status/site/{site_id}/summary
  - But: compteurs par type pour affichages (ex: { connection_errors, battery_errors, ok, unknown }).

---

### Endpoints hiérarchiques alternatifs (si vous préférez éviter un gros /full)
- [NOUVEAU] GET /sites/{site_id}/batiments -> [Batiment]
- [NOUVEAU] GET /batiments/{batiment_id}/etages -> [Etage]
- [NOUVEAU] GET /etages/{etage_id}/baes -> [Baes] (avec latest_status)

Ces endpoints fragmentés multiplient les requêtes; /sites/{id}/full reste le plus simple pour le Drawer.

---

### Récapitulatif minimal à implémenter côté backend
Obligatoires pour couvrir tout le besoin du LeftDrawer:
1) GET /me — User avec roles[] et sites[] (SiteLite)
2) GET /sites/{site_id}/full — Site complet avec batiments -> etages -> baes + latest_status sur chaque BAES
3) PUT /status/baes/{baes_id}/type/{erreur} — ignorer / acquitter (déjà présent)

Optionnels (améliorent UX/performance):
4) GET /sites/{site_id}/baes/unassigned — tuile « Non placé » rapide
5) GET /status/site/{site_id}/latest — latest par site
6) GET /status/site/{site_id}/summary — compteurs par type
7) GET /sites/my — liste sites de l’utilisateur

---

### Notes d’implémentation
- /sites/{site_id}/full: incluez latest_status pour chaque BAES; vous pouvez omettre statuses[] ou le restreindre aux types 0/4/6.
- /me: permet de décider l’affichage du bouton admin/superadmin et le peuplement du Dropdown sans autre appel.
- Les actions Ignorer/Acquitter peuvent, si besoin, enregistrer acknowledged_by_user_id et acknowledged_at via PUT /status/{status_id}/status.
- Si la payload de /full est lourde, prévoyez des flags d’inclusion: GET /sites/{id}/full?include=batiments,etages,baes,status_latest.

Si vous le souhaitez, je peux générer un mini contrat OpenAPI (YAML/JSON) pour ces endpoints à intégrer côté backend.
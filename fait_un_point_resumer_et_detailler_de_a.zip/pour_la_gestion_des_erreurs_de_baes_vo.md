
# Solution pour la gestion des erreurs BAES

Pour implémenter la gestion des erreurs BAES selon les spécifications, nous devons créer un nouveau service API pour gérer les erreurs et modifier la page de visualisation pour récupérer et afficher ces erreurs.

## 1. Création du service API pour les erreurs

Créez un nouveau fichier `lib/services/api/erreurs_api.dart` avec le contenu suivant :

```dart
part of "../../main.dart";

class ErreursApi {
  static String baseUrl = Config.baseUrl;

  /// Récupère la liste de toutes les erreurs
  static Future<List<HistoriqueErreur>> getAllErreurs() async {
    final url = Uri.parse('$baseUrl/erreurs/');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final List<dynamic> jsonData = jsonDecode(response.body);
        return jsonData.map((json) => HistoriqueErreur.fromJson(json)).toList();
      } else {
        throw Exception('Erreur lors de la récupération des erreurs. Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception lors de la récupération des erreurs: $e');
      return [];
    }
  }

  /// Récupère une erreur spécifique par son ID
  static Future<HistoriqueErreur?> getErreurById(int erreurId) async {
    final url = Uri.parse('$baseUrl/erreurs/$erreurId');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        return HistoriqueErreur.fromJson(jsonData);
      } else {
        throw Exception('Erreur lors de la récupération de l\'erreur. Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception lors de la récupération de l\'erreur: $e');
      return null;
    }
  }

  /// Récupère toutes les erreurs avec un ID supérieur à celui spécifié
  static Future<List<HistoriqueErreur>> getErreursAfter(int erreurId) async {
    final url = Uri.parse('$baseUrl/erreurs/after/$erreurId');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final List<dynamic> jsonData = jsonDecode(response.body);
        return jsonData.map((json) => HistoriqueErreur.fromJson(json)).toList();
      } else {
        throw Exception('Erreur lors de la récupération des erreurs. Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception lors de la récupération des erreurs: $e');
      return [];
    }
  }

  /// Récupère toutes les erreurs associées à un BAES spécifique
  static Future<List<HistoriqueErreur>> getErreursByBaes(int baesId) async {
    final url = Uri.parse('$baseUrl/erreurs/baes/$baesId');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final List<dynamic> jsonData = jsonDecode(response.body);
        return jsonData.map((json) => HistoriqueErreur.fromJson(json)).toList();
      } else {
        throw Exception('Erreur lors de la récupération des erreurs du BAES. Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception lors de la récupération des erreurs du BAES: $e');
      return [];
    }
  }

  /// Récupère la liste des erreurs qui ont été acquittées
  static Future<List<HistoriqueErreur>> getAcknowledgedErreurs() async {
    final url = Uri.parse('$baseUrl/erreurs/acknowledged');

    try {
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final List<dynamic> jsonData = jsonDecode(response.body);
        return jsonData.map((json) => HistoriqueErreur.fromJson(json)).toList();
      } else {
        throw Exception('Erreur lors de la récupération des erreurs acquittées. Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception lors de la récupération des erreurs acquittées: $e');
      return [];
    }
  }

  /// Crée une nouvelle entrée d'erreur
  static Future<HistoriqueErreur?> createErreur({
    required int baesId,
    required String typeErreur,
    bool? isSolved,
    bool? isIgnored,
  }) async {
    final url = Uri.parse('$baseUrl/erreurs/');
    final Map<String, dynamic> body = {
      'baes_id': baesId,
      'type_erreur': typeErreur,
    };

    if (isSolved != null) {
      body['is_solved'] = isSolved;
    }
    if (isIgnored != null) {
      body['is_ignored'] = isIgnored;
    }

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      if (response.statusCode == 201) {
        final jsonData = jsonDecode(response.body);
        return HistoriqueErreur.fromJson(jsonData);
      } else {
        throw Exception('Erreur lors de la création de l\'erreur. Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception lors de la création de l\'erreur: $e');
      return null;
    }
  }

  /// Modifie les détails d'une erreur existante
  static Future<HistoriqueErreur?> updateErreur(
    int erreurId, {
    int? baesId,
    String? typeErreur,
    bool? isSolved,
    bool? isIgnored,
  }) async {
    final url = Uri.parse('$baseUrl/erreurs/$erreurId');
    final Map<String, dynamic> body = {};

    if (baesId != null) {
      body['baes_id'] = baesId;
    }
    if (typeErreur != null) {
      body['type_erreur'] = typeErreur;
    }
    if (isSolved != null) {
      body['is_solved'] = isSolved;
    }
    if (isIgnored != null) {
      body['is_ignored'] = isIgnored;
    }

    try {
      final response = await http.put(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        return HistoriqueErreur.fromJson(jsonData);
      } else {
        throw Exception('Erreur lors de la mise à jour de l\'erreur. Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception lors de la mise à jour de l\'erreur: $e');
      return null;
    }
  }

  /// Acquitte une erreur (marque comme résolu/ignoré)
  static Future<HistoriqueErreur?> acknowledgeErreur(
    int erreurId, {
    required bool isSolved,
    required bool isIgnored,
  }) async {
    final url = Uri.parse('$baseUrl/erreurs/$erreurId/status');
    final Map<String, dynamic> body = {
      'is_solved': isSolved,
      'is_ignored': isIgnored,
    };

    try {
      final response = await http.put(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );

      if (response.statusCode == 200) {
        final jsonData = jsonDecode(response.body);
        return HistoriqueErreur.fromJson(jsonData);
      } else {
        throw Exception('Erreur lors de l\'acquittement de l\'erreur. Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception lors de l\'acquittement de l\'erreur: $e');
      return null;
    }
  }

  /// Supprime une erreur par son ID
  static Future<bool> deleteErreur(int erreurId) async {
    final url = Uri.parse('$baseUrl/erreurs/$erreurId');

    try {
      final response = await http.delete(url);

      if (response.statusCode == 200) {
        return true;
      } else {
        throw Exception('Erreur lors de la suppression de l\'erreur. Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Exception lors de la suppression de l\'erreur: $e');
      return false;
    }
  }
}
```

## 2. Modification de la page ViewCartePage

Modifiez la classe `_ViewCartePageState` dans `lib/pages/view_carte_page.dart` pour ajouter la gestion des erreurs :

```dart
class _ViewCartePageState extends State<ViewCartePage> {
  // Ajouter ces propriétés pour la gestion des erreurs
  List<HistoriqueErreur> erreurs = [];
  int? lastErreurId;
  Timer? erreurTimer;

  @override
  void initState() {
    super.initState();
    // Charger les données depuis l'API si aucune donnée n'est déjà chargée et qu'aucun chargement n'est en cours
    if (userSites.isEmpty && !isDataLoading) {
      _loadApiData();
    } else {
      // Préparer les données du site pour l'affichage
      _prepareSiteData();
    }
    
    // Charger toutes les erreurs au démarrage
    _loadAllErreurs();
    
    // Démarrer le timer pour vérifier les nouvelles erreurs toutes les 5 secondes
    erreurTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      _checkForNewErreurs();
    });
  }

  @override
  void dispose() {
    // Annuler le timer lors de la destruction du widget
    erreurTimer?.cancel();
    super.dispose();
  }

  /// Charge toutes les erreurs depuis l'API
  Future<void> _loadAllErreurs() async {
    try {
      final allErreurs = await ErreursApi.getAllErreurs();
      setState(() {
        erreurs = allErreurs;
        // Mettre à jour le dernier ID d'erreur connu
        if (erreurs.isNotEmpty) {
          lastErreurId = erreurs.map((e) => e.id).reduce((a, b) => a > b ? a : b);
        }
      });
      print('Erreurs chargées: ${erreurs.length}');
    } catch (e) {
      print('Erreur lors du chargement des erreurs: $e');
    }
  }

  /// Vérifie s'il y a de nouvelles erreurs
  Future<void> _checkForNewErreurs() async {
    try {
      if (lastErreurId == null) {
        // Si aucune erreur n'a été chargée, charger toutes les erreurs
        await _loadAllErreurs();
        return;
      }

      // Récupérer la dernière erreur disponible
      final latestErreurs = await ErreursApi.getAllErreurs();
      if (latestErreurs.isEmpty) return;

      final latestErreurId = latestErreurs.map((e) => e.id).reduce((a, b) => a > b ? a : b);

      // Si la dernière erreur est différente de celle connue, récupérer toutes les erreurs après celle connue
      if (latestErreurId > lastErreurId!) {
        final newErreurs = await ErreursApi.getErreursAfter(lastErreurId!);
        setState(() {
          // Ajouter les nouvelles erreurs à la liste existante
          erreurs.addAll(newErreurs);
          // Mettre à jour le dernier ID d'erreur connu
          lastErreurId = latestErreurId;
        });
        print('Nouvelles erreurs trouvées: ${newErreurs.length}');
        
        // Vous pouvez ajouter ici une notification ou une alerte pour informer l'utilisateur des nouvelles erreurs
        _showNewErrorsNotification(newErreurs);
      }
    } catch (e) {
      print('Erreur lors de la vérification des nouvelles erreurs: $e');
    }
  }

  /// Affiche une notification pour les nouvelles erreurs
  void _showNewErrorsNotification(List<HistoriqueErreur> newErreurs) {
    if (newErreurs.isEmpty) return;
    
    // Exemple d'affichage d'une notification avec SnackBar
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${newErreurs.length} nouvelle(s) erreur(s) détectée(s)'),
        duration: const Duration(seconds: 5),
        action: SnackBarAction(
          label: 'Voir',
          onPressed: () {
            // Naviguer vers une page de détail des erreurs ou afficher un dialogue
            _showErrorsDialog(newErreurs);
          },
        ),
      ),
    );
  }

  /// Affiche un dialogue avec les détails des erreurs
  void _showErrorsDialog(List<HistoriqueErreur> erreurs) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Détails des erreurs'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: erreurs.length,
            itemBuilder: (context, index) {
              final erreur = erreurs[index];
              return ListTile(
                title: Text('BAES ID: ${erreur.baesId}'),
                subtitle: Text('Type: ${erreur.typeErreur}\nDate: ${erreur.timestamp.toString()}'),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Fermer'),
          ),
        ],
      ),
    );
  }

  // Le reste du code existant...
}
```

## 3. Intégration dans le projet

1. Assurez-vous d'ajouter l'import du nouveau service API dans le fichier `main.dart` :

```dart
// Dans main.dart, ajoutez cette ligne avec les autres imports
part 'services/api/erreurs_api.dart';
```

2. Assurez-vous que le modèle `HistoriqueErreur` est correctement importé dans le fichier `main.dart` :

```dart
// Dans main.dart, vérifiez que cette ligne existe avec les autres imports
part 'models/historique_erreur.dart';
```

## Résumé de l'implémentation

Cette solution implémente les fonctionnalités demandées :

1. Au démarrage, la page récupère toutes les erreurs des BAES présents dans le site
2. Un timer est lancé pour vérifier toutes les 5 secondes s'il y a de nouvelles erreurs
3. Si une nouvelle erreur est détectée, la page récupère toutes les erreurs après la dernière erreur connue
4. Les nouvelles erreurs sont affichées à l'utilisateur via une notification

Le service API `ErreursApi` fournit toutes les méthodes nécessaires pour interagir avec l'API d'erreurs, conformément à la documentation fournie.
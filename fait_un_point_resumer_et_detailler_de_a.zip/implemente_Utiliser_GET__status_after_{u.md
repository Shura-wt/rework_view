### Objectif
- Sondage léger via GET /status/latest toutes les 5s pour détecter un changement.
- Seulement en cas de différence détectée, appeler GET /status/after/{updated_at} avec le dernier updated_at connu (envoyé en UTC) pour récupérer tous les nouveaux statuts.
- Maintenir un état “dernier statut par BAES” et notifier uniquement les widgets concernés.
- Persister lastUpdatedAt pour reprendre correctement au redémarrage.
- Gestion d’erreurs uniforme (logs debug + message utilisateur si nécessaire via l’UI).
- Dates: réception (UTC+00) déjà convertie en UTC+02 via json_utils.asDateTime; envoi d’horaires vers l’API en UTC.

---

### Nouveau service: lib/services/status_poller.dart
Collez ce fichier. Il n’importe que des éléments déjà présents dans votre projet.

```dart
// lib/services/status_poller.dart
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../auth/session.dart';
import '../api/api.dart';
import '../models/models.dart';

class LatestStatusChange {
  final List<BaeStatus> changed; // Statuts réellement intégrés (modifiant l’état)
  final DateTime? lastUpdatedAt;
  LatestStatusChange({required this.changed, required this.lastUpdatedAt});
}

class LatestStatusPoller {
  static final LatestStatusPoller instance = LatestStatusPoller._internal();
  LatestStatusPoller._internal();

  // Map des derniers statuts par BAES (clé = baesId)
  final ValueNotifier<Map<int, BaeStatus>> perBaesNotifier =
      ValueNotifier<Map<int, BaeStatus>>({});

  // Notifie quand un changement est appliqué (utile pour bandeau/info)
  final ValueNotifier<LatestStatusChange?> lastChangeNotifier =
      ValueNotifier<LatestStatusChange?>(null);

  // Notifiers unitaires par BAES (pour rafraîchir un widget ciblé)
  final Map<int, ValueNotifier<BaeStatus?>> _perBaesSingle = {};

  Timer? _timer;
  bool _running = false;
  bool _fetching = false;
  Duration _interval = const Duration(seconds: 5);

  DateTime? _lastUpdatedAt; // Reçu en UTC+02 (via parseurs). À envoyer en UTC à l’API.

  // Persistence key
  static const _kLastUpdatedKey = 'latest_status_last_updated_at';

  // Mapper code -> libellé lisible
  static String errorCodeToLabel(int code) {
    switch (code) {
      case 0:
        return 'erreur_connexion';
      case 4:
        return 'erreur_batterie';
      case 6:
        return 'ok';
      default:
        return 'unknown';
    }
  }

  ValueNotifier<BaeStatus?> getNotifierFor(int baesId) {
    return _perBaesSingle.putIfAbsent(baesId, () {
      final initial = perBaesNotifier.value[baesId];
      return ValueNotifier<BaeStatus?>(initial);
    });
  }

  Future<void> start({Duration interval = const Duration(seconds: 5)}) async {
    if (_running) return;
    _interval = interval;
    await _loadLastUpdatedFromPrefs();
    _running = true;
    await _tick(); // Premier tick immédiat
    _timer = Timer.periodic(_interval, (_) => _tick());
  }

  void stop() {
    _running = false;
    _timer?.cancel();
    _timer = null;
  }

  Future<void> _loadLastUpdatedFromPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final s = prefs.getString(_kLastUpdatedKey);
      if (s != null && s.isNotEmpty) {
        _lastUpdatedAt = DateTime.tryParse(s);
        if (kDebugMode) {
          debugPrint('[DEBUG_LOG] status_poller_load lastUpdatedAt=$_lastUpdatedAt');
        }
      }
    } catch (e) {
      ApiErrorHandler.logDebug(e, context: 'status_poller_load');
    }
  }

  Future<void> _saveLastUpdatedToPrefs(DateTime? dt) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (dt == null) {
        await prefs.remove(_kLastUpdatedKey);
      } else {
        await prefs.setString(_kLastUpdatedKey, dt.toIso8601String());
      }
    } catch (e) {
      ApiErrorHandler.logDebug(e, context: 'status_poller_save');
    }
  }

  Future<void> _tick() async {
    if (!_running || _fetching) return;
    _fetching = true;
    try {
      final api = StatusApi(SessionManager.instance.client);

      // 1) Probe léger: /status/latest
      final latestList = await api.latest();
      if (latestList.isEmpty) return;

      // 2) Changement détecté ?
      final changed = _detectChange(latestList);
      if (!changed) return; // rien n’a changé

      // 3) S’il y a un changement, on tire les nouveautés depuis la dernière date connue
      final afterSince = _lastUpdatedAt ?? _maxUpdatedAt(latestList);
      if (afterSince == null) {
        // Première initialisation: merge des latest uniquement
        _mergeAndNotify(latestList);
        _updateLastUpdatedAtFrom(latestList);
        return;
      }

      List<BaeStatus> afterList = [];
      try {
        afterList = await api.listAfter(afterSince);
      } on Object catch (e) {
        ApiErrorHandler.logDebug(e, context: 'status_poller_after');
        // Fallback minimal: intégrer latestList quand même
        _mergeAndNotify(latestList);
        _updateLastUpdatedAtFrom(latestList);
        return;
      }

      // 4) Fusionner latest + after
      final allNew = <BaeStatus>[...latestList, ...afterList];
      final actuallyChanged = _mergeAndNotify(allNew);

      // 5) Mettre à jour lastUpdatedAt et persister
      _updateLastUpdatedAtFrom(allNew);
      await _saveLastUpdatedToPrefs(_lastUpdatedAt);

      // 6) Notifier les changements effectifs
      if (actuallyChanged.isNotEmpty) {
        lastChangeNotifier.value = LatestStatusChange(
          changed: actuallyChanged,
          lastUpdatedAt: _lastUpdatedAt,
        );
      }
    } on Object catch (e) {
      ApiErrorHandler.logDebug(e, context: 'status_poller_tick');
    } finally {
      _fetching = false;
    }
  }

  bool _detectChange(List<BaeStatus> latestList) {
    // Critère robuste: max(updatedAt/timestamp) > _lastUpdatedAt
    final maxUp = _maxUpdatedAt(latestList);
    if (maxUp == null) return false;
    final last = _lastUpdatedAt;
    if (last == null) return true;
    return maxUp.toUtc().isAfter(last.toUtc());
  }

  DateTime? _maxUpdatedAt(List<BaeStatus> list) {
    DateTime? maxDt;
    for (final s in list) {
      final u = s.updatedAt ?? s.timestamp;
      if (u == null) continue;
      if (maxDt == null || u.isAfter(maxDt)) maxDt = u;
    }
    return maxDt;
  }

  // Merge: garde le statut le plus récent par BAES; retourne ceux qui ont réellement changé
  List<BaeStatus> _mergeAndNotify(List<BaeStatus> updates) {
    final current = Map<int, BaeStatus>.from(perBaesNotifier.value);
    final changed = <BaeStatus>[];

    BaeStatus pickMoreRecent(BaeStatus a, BaeStatus b) {
      final aUp = a.updatedAt ?? a.timestamp;
      final bUp = b.updatedAt ?? b.timestamp;
      if (aUp != null && bUp != null) return aUp.isAfter(bUp) ? a : b;
      final aId = a.id ?? 0;
      final bId = b.id ?? 0;
      return aId >= bId ? a : b;
    }

    // Grouper par BAES
    final grouped = <int, List<BaeStatus>>{};
    for (final s in updates) {
      if (s.baesId == null) continue;
      grouped.putIfAbsent(s.baesId!, () => []).add(s);
    }

    grouped.forEach((baesId, list) {
      final latestForBaes = list.reduce(pickMoreRecent);
      final prev = current[baesId];
      if (_statusChanged(prev, latestForBaes)) {
        current[baesId] = latestForBaes;
        changed.add(latestForBaes);
      }
    });

    if (changed.isNotEmpty) {
      perBaesNotifier.value = current;
      // Mettre à jour les notifiers unitaires
      for (final s in changed) {
        final bId = s.baesId;
        if (bId != null && _perBaesSingle.containsKey(bId)) {
          _perBaesSingle[bId]!.value = s;
        }
      }
    }
    return changed;
  }

  void _updateLastUpdatedAtFrom(List<BaeStatus> list) {
    final maxUp = _maxUpdatedAt(list);
    if (maxUp == null) return;
    if (_lastUpdatedAt == null || maxUp.isAfter(_lastUpdatedAt!)) {
      _lastUpdatedAt = maxUp;
    }
  }

  bool _statusChanged(BaeStatus? prev, BaeStatus next) {
    if (prev == null) return true;
    final pUp = (prev.updatedAt ?? prev.timestamp)?.toUtc();
    final nUp = (next.updatedAt ?? next.timestamp)?.toUtc();
    if (pUp != null || nUp != null) {
      if (pUp == null || nUp == null) return true;
      if (!pUp.isAtSameMomentAs(nUp)) return true;
    }
    if (prev.baesId != next.baesId) return true;
    if (prev.erreur != next.erreur) return true;
    if (prev.isSolved != next.isSolved) return true;
    if (prev.isIgnored != next.isIgnored) return true;
    if ((prev.temperature ?? 0) != (next.temperature ?? 0)) return true;
    if ((prev.vibration ?? false) != (next.vibration ?? false)) return true;
    return false;
  }
}
```

---

### Intégration côté UI

1) Démarrer/arrêter le poller (ex: HomePage)

```dart
@override
void initState() {
  super.initState();
  LatestStatusPoller.instance.start(interval: const Duration(seconds: 5));
}

@override
void dispose() {
  LatestStatusPoller.instance.stop();
  super.dispose();
}
```

Au logout, arrêtez le poller pour économiser les ressources et éviter des appels authentifiés après déconnexion :

```dart
try {
  LatestStatusPoller.instance.stop();
  await SessionManager.instance.logout();
} on Object catch (e) {
  ApiErrorHandler.logDebug(e, context: 'logout');
  if (mounted) ApiErrorHandler.showSnackBar(context, e, action: 'logout');
} finally {
  if (!mounted) return;
  Navigator.pushReplacementNamed(context, '/login');
}
```

2) Rafraîchir un widget spécifique (par BAES)

```dart
import 'package:flutter/material.dart';
import '../services/status_poller.dart';
import '../models/models.dart';

class BaesTile extends StatelessWidget {
  final int baesId;
  const BaesTile({super.key, required this.baesId});

  @override
  Widget build(BuildContext context) {
    final notifier = LatestStatusPoller.instance.getNotifierFor(baesId);
    return ValueListenableBuilder<BaeStatus?>(
      valueListenable: notifier,
      builder: (context, status, _) {
        if (status == null) return const Text('Aucun statut');
        final label = LatestStatusPoller.errorCodeToLabel(status.erreur ?? -1);
        final solved = status.isSolved == true ? 'résolu' : 'non résolu';
        final ignored = status.isIgnored == true ? '(ignoré)' : '';
        final updated = status.updatedAt ?? status.timestamp; // déjà UTC+02
        return ListTile(
          title: Text('BAES #$baesId: $label $ignored'),
          subtitle: Text('État: $solved — MAJ: ${updated ?? '-'}'),
        );
      },
    );
  }
}
```

3) Rafraîchir une liste/grille globale minimalement

```dart
ValueListenableBuilder<Map<int, BaeStatus>>(
  valueListenable: LatestStatusPoller.instance.perBaesNotifier,
  builder: (context, map, _) {
    final ids = map.keys.toList()..sort();
    return ListView.builder(
      itemCount: ids.length,
      itemBuilder: (_, i) => BaesTile(baesId: ids[i]),
    );
  },
)
```

4) Afficher un bandeau d’info au changement

```dart
ValueListenableBuilder<LatestStatusChange?>(
  valueListenable: LatestStatusPoller.instance.lastChangeNotifier,
  builder: (context, change, _) {
    if (change == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Text(
        'Mises à jour: ${change.changed.length} — Dernier: ${change.lastUpdatedAt}',
        style: const TextStyle(color: Colors.green),
      ),
    );
  },
)
```

---

### Détails importants
- Détection de changement: compare le max(updatedAt/timestamp) reçu dans /status/latest au dernier _lastUpdatedAt connu. Si supérieur, on lance /status/after/{updated_at}.
- Merge: pour chaque BAES, on garde le statut le plus récent (ordre de priorité: updatedAt puis timestamp puis id).
- Differenciation par BAES: map<int, BaeStatus> maintenu et Notifiers par BAES pour rafraîchir un seul widget.
- Dates: vos parseurs transforment déjà les dates reçues en UTC+02 pour l’affichage. Lorsqu’on construit une URL /status/after/{updated_at}, on convertit la date locale en UTC via toUtc().toIso8601String() côté StatusApi.listAfter (déjà implémenté ainsi dans votre code).
- Gestion d’erreurs: ApiErrorHandler.logDebug imprime code + message + body pour les erreurs réseau/serveur; l’UI peut déclencher un message utilisateur si nécessaire.

---

### Optionnel: optimisations
- Backoff exponentiel en cas d’erreurs consécutives.
- Persister aussi un snapshot minimal par BAES (JSON) pour affichage immédiat au démarrage.
- Si /status/after retourne de gros volumes, traiter par tranches temporelles.

---

### Résumé
- Service LatestStatusPoller prêt à l’emploi pour détecter un changement via /status/latest et ne tirer les nouveautés via /status/after que si nécessaire.
- Mise à jour fine par BAES avec ValueNotifiers, garantissant un rafraîchissement ciblé des widgets.
- Persistance du dernier updated_at et gestion d’erreurs cohérente.
- Respect des contraintes de fuseau horaire: entrée UTC+00 convertie vers UTC+02, envoi en UTC pour les paramètres d’API.
The issue is that when you add a BAES to a floor, the application is switching back to the site view instead of staying in the floor view. This happens because of how the notification system is implemented.

Here's what's happening:

1. When you add a BAES using the `_addBaesMarker` method (around line 70), it calls:
   ```dart
   // Notifier les écouteurs pour mettre à jour le drawer
   Provider.of<SiteProvider>(context, listen: false).notifyListeners();
   ```

2. This call to `notifyListeners()` is intended to update the drawer with the new BAES, but it has an unintended side effect.

3. The `GestionCartePage` class has a listener for site changes that's set up in `initState()`:
   ```dart
   _siteProvider.addListener(_onSiteSelectionChanged);
   ```

4. When `notifyListeners()` is called, it triggers the `_onSiteSelectionChanged` method, which explicitly sets `_isFloorMode = false;` (line 179), causing the view to switch back to the site view.

### Solution:

You have two options to fix this:

#### Option 1: Modify the `_onSiteSelectionChanged` method to only reset the floor mode if the site has actually changed:

```dart
void _onSiteSelectionChanged() {
  if (!mounted) return;
  
  // Get the current and previous site IDs
  final currentSiteId = _siteProvider.selectedSite?.id;
  
  // Only reset the view if the site has actually changed
  if (_previousSiteId != currentSiteId) {
    _previousSiteId = currentSiteId;
    
    // Reset site map data to ensure no data persistence
    setState(() {
      _siteEffectiveWidth = null;
      _siteEffectiveHeight = null;
      _currentSiteCarte = null;

      // Réinitialiser également les données d'étage
      _isFloorMode = false;
      _selectedBatiment = null;
      _selectedFloorId = null;
      _batimentEtages = [];
      _floorEffectiveWidth = null;
      _floorEffectiveHeight = null;
    });

    // Reload site map data for the newly selected site
    if (mounted) {
      _loadSiteMapData();
    }
  }
}
```

You'll need to add a `_previousSiteId` variable to the class.

#### Option 2: Use a different method to update the drawer without triggering the site change listener:

Instead of calling `notifyListeners()` on the `SiteProvider`, you could create a separate method or provider specifically for updating the drawer with new BAES information.

For a quick fix, you could simply remove the line that calls `notifyListeners()` in the `_addBaesMarker` method, since the drawer should already be updated when you call `_loadBaesForFloor(_selectedFloorId!)` just before it.

This issue is a classic example of unintended consequences in event-driven programming, where a notification meant for one component (the drawer) affects another component (the map view) because they're both listening to the same event source.